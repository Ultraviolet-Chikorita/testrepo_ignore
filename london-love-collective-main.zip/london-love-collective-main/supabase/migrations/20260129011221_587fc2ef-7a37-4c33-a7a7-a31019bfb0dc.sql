-- Create signups table for waitlist
CREATE TABLE public.signups (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    first_name TEXT NOT NULL,
    university TEXT NOT NULL,
    phone TEXT NOT NULL,
    referral_code TEXT NOT NULL UNIQUE,
    referred_by UUID REFERENCES public.signups(id),
    priority_completed BOOLEAN NOT NULL DEFAULT false,
    queue_position INTEGER,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create priority_responses table for Cupid Check data
CREATE TABLE public.priority_responses (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    signup_id UUID NOT NULL REFERENCES public.signups(id) ON DELETE CASCADE,
    instagram_handle TEXT,
    interests TEXT[] DEFAULT '{}',
    quiz_answers JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE(signup_id)
);

-- Create referrals tracking table
CREATE TABLE public.referrals (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    referrer_id UUID NOT NULL REFERENCES public.signups(id) ON DELETE CASCADE,
    referred_id UUID NOT NULL REFERENCES public.signups(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE(referred_id)
);

-- Create waitlist_counter table for live count
CREATE TABLE public.waitlist_counter (
    id INTEGER PRIMARY KEY DEFAULT 1,
    count INTEGER NOT NULL DEFAULT 0,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    CONSTRAINT single_row CHECK (id = 1)
);

-- Insert initial counter row
INSERT INTO public.waitlist_counter (id, count) VALUES (1, 412);

-- Enable RLS on all tables
ALTER TABLE public.signups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.priority_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.waitlist_counter ENABLE ROW LEVEL SECURITY;

-- Signups policies (public can insert, read their own via referral code lookup)
CREATE POLICY "Anyone can create a signup" 
ON public.signups 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Anyone can read signups for referral validation" 
ON public.signups 
FOR SELECT 
USING (true);

CREATE POLICY "Signups can update their own record" 
ON public.signups 
FOR UPDATE 
USING (true);

-- Priority responses policies
CREATE POLICY "Anyone can insert priority responses" 
ON public.priority_responses 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Anyone can read priority responses" 
ON public.priority_responses 
FOR SELECT 
USING (true);

-- Referrals policies
CREATE POLICY "Anyone can create referrals" 
ON public.referrals 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Anyone can read referrals" 
ON public.referrals 
FOR SELECT 
USING (true);

-- Waitlist counter policies (public read, insert/update via function)
CREATE POLICY "Anyone can read waitlist counter" 
ON public.waitlist_counter 
FOR SELECT 
USING (true);

CREATE POLICY "Anyone can update waitlist counter" 
ON public.waitlist_counter 
FOR UPDATE 
USING (true);

-- Enable realtime for waitlist counter
ALTER PUBLICATION supabase_realtime ADD TABLE public.waitlist_counter;

-- Function to increment counter and return new count
CREATE OR REPLACE FUNCTION public.increment_waitlist_counter()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    new_count INTEGER;
BEGIN
    UPDATE public.waitlist_counter 
    SET count = count + 1, updated_at = now() 
    WHERE id = 1
    RETURNING count INTO new_count;
    RETURN new_count;
END;
$$;

-- Function to generate unique referral code
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT
LANGUAGE plpgsql
AS $$
DECLARE
    chars TEXT := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    result TEXT := '';
    i INTEGER;
BEGIN
    FOR i IN 1..6 LOOP
        result := result || substr(chars, floor(random() * length(chars) + 1)::integer, 1);
    END LOOP;
    RETURN result;
END;
$$;