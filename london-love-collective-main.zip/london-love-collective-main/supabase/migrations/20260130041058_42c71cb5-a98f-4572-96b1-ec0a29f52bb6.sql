-- Fix remaining RLS warnings: remove permissive INSERT policies

-- Drop the overly permissive INSERT policies
DROP POLICY IF EXISTS "Anyone can create a signup" ON public.signups;
DROP POLICY IF EXISTS "Anyone can insert priority responses" ON public.priority_responses;

-- The signups and priority_responses tables now have NO public policies
-- All operations go through SECURITY DEFINER functions:
-- - create_signup() for new signups
-- - save_priority_response() for priority responses

-- Grant execute permissions on the secure functions to anon and authenticated roles
GRANT EXECUTE ON FUNCTION public.create_signup TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.save_priority_response TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.validate_referral_code TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.check_phone_exists TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.check_referral_code_exists TO anon, authenticated;