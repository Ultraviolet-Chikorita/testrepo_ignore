-- Add invite and payment columns to signups table
ALTER TABLE public.signups
ADD COLUMN invite_status text NOT NULL DEFAULT 'pending',
ADD COLUMN invite_token text UNIQUE,
ADD COLUMN invite_expires_at timestamp with time zone,
ADD COLUMN wave_number integer,
ADD COLUMN stripe_session_id text,
ADD COLUMN ticket_reference text,
ADD COLUMN claimed_at timestamp with time zone;

-- Create index on invite_token for fast lookups
CREATE INDEX idx_signups_invite_token ON public.signups(invite_token);

-- Create index on invite_status for filtering
CREATE INDEX idx_signups_invite_status ON public.signups(invite_status);

-- Create function to generate invite token (8 chars)
CREATE OR REPLACE FUNCTION public.generate_invite_token()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
    chars TEXT := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    result TEXT := '';
    i INTEGER;
BEGIN
    FOR i IN 1..8 LOOP
        result := result || substr(chars, floor(random() * length(chars) + 1)::integer, 1);
    END LOOP;
    RETURN result;
END;
$$;