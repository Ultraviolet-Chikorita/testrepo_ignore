-- =============================================
-- SECURITY FIX: Restrict data exposure
-- =============================================

-- 1. DROP overly permissive policies on signups
DROP POLICY IF EXISTS "Anyone can read signups for referral validation" ON public.signups;
DROP POLICY IF EXISTS "Signups can update their own record" ON public.signups;

-- 2. DROP overly permissive policies on priority_responses
DROP POLICY IF EXISTS "Anyone can read priority responses" ON public.priority_responses;

-- 3. DROP overly permissive policies on referrals
DROP POLICY IF EXISTS "Anyone can read referrals" ON public.referrals;

-- 4. DROP overly permissive policies on waitlist_counter
DROP POLICY IF EXISTS "Anyone can update waitlist counter" ON public.waitlist_counter;

-- =============================================
-- CREATE SECURE FUNCTIONS (instead of direct table access)
-- =============================================

-- Function to validate referral code and return referrer ID (minimal data exposure)
CREATE OR REPLACE FUNCTION public.validate_referral_code(code text)
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id FROM signups WHERE referral_code = upper(code) LIMIT 1;
$$;

-- Function to check if phone already exists (returns boolean only)
CREATE OR REPLACE FUNCTION public.check_phone_exists(phone_number text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM signups WHERE phone = phone_number);
$$;

-- Function to check if referral code exists (for uniqueness check)
CREATE OR REPLACE FUNCTION public.check_referral_code_exists(code text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM signups WHERE referral_code = code);
$$;

-- Secure signup function that handles the entire signup process
CREATE OR REPLACE FUNCTION public.create_signup(
  p_first_name text,
  p_university text,
  p_phone text,
  p_referral_code text,
  p_referred_by_code text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_referrer_id uuid;
  v_signup_id uuid;
  v_queue_position integer;
BEGIN
  -- Check for duplicate phone
  IF EXISTS (SELECT 1 FROM signups WHERE phone = p_phone) THEN
    RETURN jsonb_build_object('error', 'Phone number already registered');
  END IF;

  -- Get referrer if code provided
  IF p_referred_by_code IS NOT NULL AND p_referred_by_code != '' THEN
    SELECT id INTO v_referrer_id FROM signups WHERE referral_code = upper(p_referred_by_code);
  END IF;

  -- Insert signup
  INSERT INTO signups (first_name, university, phone, referral_code, referred_by)
  VALUES (p_first_name, p_university, p_phone, p_referral_code, v_referrer_id)
  RETURNING id INTO v_signup_id;

  -- Create referral record if applicable
  IF v_referrer_id IS NOT NULL THEN
    INSERT INTO referrals (referrer_id, referred_id)
    VALUES (v_referrer_id, v_signup_id);
  END IF;

  -- Increment counter and get position
  UPDATE waitlist_counter SET count = count + 1, updated_at = now() WHERE id = 1
  RETURNING count INTO v_queue_position;

  RETURN jsonb_build_object(
    'id', v_signup_id,
    'referral_code', p_referral_code,
    'queue_position', v_queue_position
  );
END;
$$;

-- Secure function to save priority responses
CREATE OR REPLACE FUNCTION public.save_priority_response(
  p_signup_id uuid,
  p_instagram_handle text DEFAULT NULL,
  p_interests text[] DEFAULT '{}',
  p_quiz_answers jsonb DEFAULT '{}'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_response_id uuid;
BEGIN
  -- Verify signup exists
  IF NOT EXISTS (SELECT 1 FROM signups WHERE id = p_signup_id) THEN
    RETURN jsonb_build_object('error', 'Invalid signup ID');
  END IF;

  -- Check if response already exists
  IF EXISTS (SELECT 1 FROM priority_responses WHERE signup_id = p_signup_id) THEN
    RETURN jsonb_build_object('error', 'Priority response already submitted');
  END IF;

  -- Insert response
  INSERT INTO priority_responses (signup_id, instagram_handle, interests, quiz_answers)
  VALUES (p_signup_id, p_instagram_handle, p_interests, p_quiz_answers)
  RETURNING id INTO v_response_id;

  -- Mark signup as priority completed
  UPDATE signups SET priority_completed = true WHERE id = p_signup_id;

  RETURN jsonb_build_object('success', true, 'id', v_response_id);
END;
$$;

-- =============================================
-- NEW RESTRICTIVE POLICIES
-- =============================================

-- Signups: No public SELECT (use functions instead)
-- Keep INSERT for new signups
-- No UPDATE or DELETE for public

-- Priority responses: INSERT only (no SELECT)
-- Already has INSERT policy, SELECT removed above

-- Referrals: No public access (handled by create_signup function)
-- Remove existing INSERT policy and handle via function
DROP POLICY IF EXISTS "Anyone can create referrals" ON public.referrals;

-- Waitlist counter: SELECT only (UPDATE via increment function)
-- Already has SELECT policy, UPDATE removed above