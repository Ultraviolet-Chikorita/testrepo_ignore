-- Create secure function to get referral count
CREATE OR REPLACE FUNCTION public.get_referral_count(p_signup_id uuid)
RETURNS integer
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COUNT(*)::integer
  FROM referrals
  WHERE referrer_id = p_signup_id;
$$;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION public.get_referral_count TO anon, authenticated;