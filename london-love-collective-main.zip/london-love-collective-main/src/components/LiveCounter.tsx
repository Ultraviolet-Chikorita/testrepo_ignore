import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";

export function LiveCounter() {
  const [count, setCount] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);
  const [prevCount, setPrevCount] = useState<number>(0);

  useEffect(() => {
    // Fetch initial count
    const fetchCount = async () => {
      const { data, error } = await supabase
        .from("waitlist_counter")
        .select("count")
        .eq("id", 1)
        .single();

      if (data && !error) {
        setCount(data.count);
        setPrevCount(data.count);
      }
      setIsLoading(false);
    };

    fetchCount();

    // Subscribe to realtime updates
    const channel = supabase
      .channel("waitlist-counter-changes")
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "waitlist_counter",
        },
        (payload) => {
          if (payload.new && typeof payload.new === "object" && "count" in payload.new) {
            setPrevCount(count);
            setCount(payload.new.count as number);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const digits = count.toString().split("");

  return (
    <motion.div
      className="flex items-center gap-3 px-6 py-4 rounded-2xl bg-background/80 backdrop-blur-sm border border-border/50"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ type: "spring", stiffness: 200 }}
    >
      <div className="flex items-center gap-0.5">
        <AnimatePresence mode="popLayout">
          {isLoading ? (
            <motion.span
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: [0.3, 0.7, 0.3] }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="font-display text-4xl md:text-5xl font-bold text-primary"
            >
              ...
            </motion.span>
          ) : (
            digits.map((digit, index) => (
              <motion.span
                key={`${index}-${digit}`}
                initial={{ opacity: 0, y: 20, rotateX: -90 }}
                animate={{ opacity: 1, y: 0, rotateX: 0 }}
                exit={{ opacity: 0, y: -20, rotateX: 90 }}
                transition={{
                  duration: 0.4,
                  delay: index * 0.05,
                  type: "spring",
                  stiffness: 300,
                }}
                className="font-display text-4xl md:text-5xl font-bold metallic-heart inline-block min-w-[1ch] text-center"
              >
                {digit}
              </motion.span>
            ))
          )}
        </AnimatePresence>
      </div>
      <motion.span
        className="text-muted-foreground font-body text-sm md:text-base tracking-wide uppercase"
        initial={{ opacity: 0, x: -10 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.5 }}
      >
        on the list
      </motion.span>
    </motion.div>
  );
}
