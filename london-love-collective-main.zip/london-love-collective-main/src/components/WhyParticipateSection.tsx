import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { Flame, Theater, Wine } from "lucide-react";

const features = [
  {
    icon: Flame,
    title: "Audience games",
    subtitle: "(you can't hide)",
    direction: -1, // From left
  },
  {
    icon: Theater,
    title: "Live show on stage",
    subtitle: "(chaos included)",
    direction: 0, // From center (below)
  },
  {
    icon: Wine,
    title: "Afterparty",
    subtitle: "(meet people properly)",
    direction: 1, // From right
  },
];

export function WhyParticipateSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });
  
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });
  
  const backgroundY = useTransform(scrollYProgress, [0, 1], [100, -100]);
  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0.3, 1, 1, 0.3]);
  
  // Individual card parallax for depth
  const leftCardY = useTransform(scrollYProgress, [0, 0.5, 1], [40, 0, -30]);
  const centerCardY = useTransform(scrollYProgress, [0, 0.5, 1], [60, 0, -20]);
  const rightCardY = useTransform(scrollYProgress, [0, 0.5, 1], [40, 0, -30]);
  const cardParallax = [leftCardY, centerCardY, rightCardY];
  
  // Emphasis text scale on scroll
  const emphasisScale = useTransform(scrollYProgress, [0.4, 0.6, 0.8], [0.95, 1.02, 1]);

  return (
    <section ref={ref} className="py-12 md:py-16 bg-secondary/50 overflow-hidden relative">
      {/* Continuation of red gradient from hero */}
      <div className="absolute top-0 left-0 right-0 h-48 bg-gradient-to-b from-primary/[0.23] via-primary/[0.08] to-transparent pointer-events-none z-[1]" />
      {/* Parallax background decoration */}
      <motion.div 
        className="absolute inset-0 pointer-events-none"
        style={{ y: backgroundY, opacity }}
      >
        <div className="absolute top-20 left-10 w-32 h-32 bg-primary/5 rounded-full blur-2xl" />
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-primary/5 rounded-full blur-2xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-primary/3 rounded-full blur-3xl" />
      </motion.div>

      <div className="container px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 60, filter: "blur(10px)" }}
          animate={isInView ? { opacity: 1, y: 0, filter: "blur(0px)" } : {}}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="max-w-3xl mx-auto text-center"
        >
          {/* Animated heading with dramatic reveal */}
          <motion.h2
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="font-display text-3xl md:text-5xl font-semibold mb-4"
          >
            <motion.span
              initial={{ opacity: 0, x: -30 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.4, delay: 0.1 }}
              className="inline-block"
            >
              You don't come to
            </motion.span>{" "}
            <motion.span
              initial={{ opacity: 0, scale: 0.5, rotate: -10, filter: "blur(10px)" }}
              animate={isInView ? { opacity: 1, scale: 1, rotate: 0, filter: "blur(0px)" } : {}}
              transition={{ 
                duration: 0.5, 
                delay: 0.3,
                type: "spring",
                stiffness: 300,
                damping: 15
              }}
              className="italic text-muted-foreground inline-block origin-left"
            >
              'watch.'
            </motion.span>
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.4, duration: 0.4 }}
            className="font-body text-muted-foreground mb-16 text-lg"
          >
            This isn't a spectator sport.
          </motion.p>
          
          {/* Feature grid with snappy staggered reveal */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ 
                  opacity: 0, 
                  x: feature.direction * 80,
                  y: feature.direction === 0 ? 60 : 30,
                  scale: 0.85,
                  rotateY: feature.direction * -15,
                }}
                animate={isInView ? { 
                  opacity: 1, 
                  x: 0,
                  y: 0, 
                  scale: 1,
                  rotateY: 0,
                } : {}}
                transition={{ 
                  duration: 0.45,
                  delay: 0.5 + index * 0.08,
                  type: "spring",
                  stiffness: 350,
                  damping: 25,
                }}
                whileHover={{ 
                  y: -12, 
                  scale: 1.04,
                  transition: { duration: 0.25, type: "spring", stiffness: 400 } 
                }}
                className="group"
                style={{ 
                  perspective: "1000px",
                  y: cardParallax[index],
                }}
              >
                <motion.div
                  className="flex flex-col items-center p-8 rounded-2xl bg-white/70 dark:bg-white/10 backdrop-blur-md border border-white/40 shadow-lg shadow-black/5 hover:border-primary/40 transition-colors relative overflow-hidden"
                  whileHover={{
                    boxShadow: "0 30px 60px -15px hsl(0 75% 28% / 0.25)",
                  }}
                >
                  {/* Hover gradient sweep */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent"
                    initial={{ opacity: 0, x: "-100%" }}
                    whileHover={{ opacity: 1, x: "0%" }}
                    transition={{ duration: 0.3 }}
                  />
                  
                  {/* Metallic ring glow on reveal */}
                  <motion.div
                    className="absolute inset-0 rounded-2xl"
                    initial={{ boxShadow: "inset 0 0 0 0 hsl(0 75% 40% / 0)" }}
                    animate={isInView ? { 
                      boxShadow: [
                        "inset 0 0 0 0 hsl(0 75% 40% / 0)",
                        "inset 0 0 30px 2px hsl(0 75% 40% / 0.15)",
                        "inset 0 0 0 0 hsl(0 75% 40% / 0)"
                      ]
                    } : {}}
                    transition={{ 
                      duration: 0.8, 
                      delay: 0.6 + index * 0.1,
                      ease: "easeOut"
                    }}
                  />
                  
                  <motion.div
                    initial={{ scale: 0, rotate: -180 }}
                    animate={isInView ? { scale: 1, rotate: 0 } : {}}
                    transition={{
                      type: "spring",
                      stiffness: 400,
                      damping: 15,
                      delay: 0.6 + index * 0.08,
                    }}
                    whileHover={{ rotate: [0, -15, 15, 0], scale: 1.15 }}
                    className="relative"
                  >
                    {/* Icon glow */}
                    <motion.div
                      className="absolute inset-0 bg-primary/30 rounded-full blur-xl scale-150 opacity-0 group-hover:opacity-100"
                      transition={{ duration: 0.3 }}
                    />
                    <motion.div
                      className="relative z-10"
                      animate={{
                        scale: [1, 1.12, 1],
                        rotate: [0, 5, -5, 0],
                      }}
                      transition={{
                        duration: 3,
                        repeat: Infinity,
                        ease: "easeInOut",
                        delay: 1 + index * 0.8,
                      }}
                    >
                      <feature.icon
                        size={40}
                        className="text-primary mb-4"
                      />
                    </motion.div>
                  </motion.div>
                  <h3 className="font-display text-xl font-medium mb-1 relative z-10">
                    {feature.title}
                  </h3>
                  <p className="font-body text-sm text-muted-foreground italic relative z-10">
                    {feature.subtitle}
                  </p>
                </motion.div>
              </motion.div>
            ))}
          </div>
          
          {/* Emphasis text with dramatic scale punch and scroll effect */}
          <div className="relative">
            {/* Gradient glow behind emphasis text */}
            <div className="absolute inset-0 -inset-x-8 -inset-y-4 bg-gradient-to-r from-transparent via-primary/10 to-transparent rounded-full blur-xl pointer-events-none" />
            
            <motion.p
              initial={{ opacity: 0, scale: 0.8, y: 30 }}
              animate={isInView ? { opacity: 1, scale: 1, y: 0 } : {}}
              transition={{ 
                duration: 0.5, 
                delay: 0.85, 
                type: "spring",
                stiffness: 200
              }}
              className="font-display text-xl md:text-2xl text-foreground relative"
              style={{ scale: emphasisScale }}
            >
              You leave with{" "}
              <motion.span
                initial={{ opacity: 0, scale: 1.3, filter: "blur(8px)" }}
                animate={isInView ? { opacity: 1, scale: 1, filter: "blur(0px)" } : {}}
                transition={{ 
                  duration: 0.4, 
                  delay: 1,
                  type: "spring",
                  stiffness: 300
                }}
                className="metallic-heart font-semibold inline-block"
              >
                at least one new connection.
              </motion.span>
            </motion.p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
