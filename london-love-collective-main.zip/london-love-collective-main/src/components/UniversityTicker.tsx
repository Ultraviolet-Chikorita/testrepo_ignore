import { motion } from "framer-motion";

const universities = [
  "Imperial",
  "UCL",
  "KCL",
  "UAL",
  "City",
  "LSE",
  "Queen Mary",
  "Goldsmiths",
  "Westminster",
  "SOAS",
  "Royal Holloway",
  "Brunel",
];

export function UniversityTicker() {
  return (
    <div 
      className="relative overflow-hidden py-8 md:py-10 border-y border-red-950/50 bg-gradient-to-b from-red-800 via-red-900 to-red-800"
      style={{
        boxShadow: "0 4px 20px -4px rgba(127,29,29,0.3), 0 -4px 20px -4px rgba(127,29,29,0.3), inset 0 1px 0 rgba(255,255,255,0.1), inset 0 -1px 0 rgba(0,0,0,0.2)"
      }}
    >
      <motion.div
        className="flex gap-8 whitespace-nowrap"
        animate={{ x: ["0%", "-80%"] }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "linear",
          repeatType: "loop",
        }}
      >
        {/* Repeat 5x so each university appears exactly 5 times */}
        {[...Array(5)].flatMap(() => universities).map((uni, index) => (
          <motion.span
            key={`${uni}-${index}`}
            className="font-display text-xl md:text-2xl text-white/90 font-semibold tracking-widest uppercase"
            whileHover={{ scale: 1.1, color: "hsl(0 0% 100%)" }}
            transition={{ duration: 0.2 }}
          >
            {uni}
            <motion.span
              className="mx-6 text-white"
              style={{ textShadow: "0 0 12px rgba(255,255,255,0.5)" }}
              animate={{ opacity: [0.6, 1, 0.6] }}
              transition={{ duration: 2, repeat: Infinity, delay: index * 0.1 }}
            >
              ♥
            </motion.span>
          </motion.span>
        ))}
      </motion.div>
      
      {/* Fade edges with animation */}
      <motion.div
        className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-red-900 via-red-900/80 to-transparent pointer-events-none"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      />
      <motion.div
        className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-red-900 via-red-900/80 to-transparent pointer-events-none"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      />
    </div>
  );
}
