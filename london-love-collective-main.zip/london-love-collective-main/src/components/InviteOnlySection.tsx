import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { useRef, useEffect, useState } from "react";
import { Users, Video, Scale } from "lucide-react";

const reasons = [
  {
    icon: Users,
    title: "300 seats",
    countUp: 300,
    description: "(hard cap)",
  },
  {
    icon: Video,
    title: "Filming consent",
    countUp: null,
    description: "required",
  },
  {
    icon: Scale,
    title: "Balanced ratios",
    countUp: null,
    description: "across universities",
  },
];

function CountUpNumber({ target, isInView }: { target: number; isInView: boolean }) {
  const [count, setCount] = useState(0);
  
  useEffect(() => {
    if (!isInView) return;
    
    const duration = 1500;
    const steps = 40;
    const increment = target / steps;
    const stepDuration = duration / steps;
    
    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, stepDuration);
    
    return () => clearInterval(timer);
  }, [isInView, target]);
  
  return <span>{count}</span>;
}

export function InviteOnlySection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });
  
  const backgroundY = useTransform(scrollYProgress, [0, 1], [80, -80]);
  const particleY = useTransform(scrollYProgress, [0, 1], [0, -150]);

  return (
    <section ref={ref} className="py-24 md:py-32 bg-charcoal text-white relative overflow-hidden">
      {/* Animated background particles with parallax */}
      <motion.div 
        className="absolute inset-0 overflow-hidden pointer-events-none"
        style={{ y: particleY }}
      >
        {[...Array(16)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              left: `${8 + (i * 6) % 84}%`,
              top: `${10 + (i * 9) % 80}%`,
              width: `${8 + (i % 5) * 4}px`,
              height: `${8 + (i % 5) * 4}px`,
              background: `radial-gradient(circle, hsl(0 75% 45% / ${0.25 + (i % 4) * 0.1}) 0%, transparent 70%)`,
            }}
            animate={{
              y: [0, -50 - (i % 4) * 25, 0],
              x: [0, (i % 2 === 0 ? 20 : -20), 0],
              opacity: [0.3, 0.7, 0.3],
              scale: [1, 1.4, 1],
            }}
            transition={{
              duration: 4 + i % 3,
              repeat: Infinity,
              delay: i * 0.2,
              ease: "easeInOut",
            }}
          />
        ))}
      </motion.div>
      
      {/* Gradient orbs with parallax */}
      <motion.div
        className="absolute top-0 left-1/4 w-72 h-72 bg-primary/15 rounded-full blur-3xl"
        style={{ y: backgroundY }}
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.4, 0.6, 0.4],
        }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute bottom-0 right-1/4 w-56 h-56 bg-primary/15 rounded-full blur-3xl"
        style={{ y: backgroundY }}
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.5, 0.3, 0.5],
        }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
      />

      <div className="container px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 60, filter: "blur(10px)" }}
          animate={isInView ? { opacity: 1, y: 0, filter: "blur(0px)" } : {}}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="max-w-3xl mx-auto text-center"
        >
          <motion.h2
            initial={{ opacity: 0, y: 30, scale: 0.9 }}
            animate={isInView ? { opacity: 1, y: 0, scale: 1 } : {}}
            transition={{ 
              duration: 0.5, 
              type: "spring",
              stiffness: 200
            }}
            className="font-display text-3xl md:text-5xl font-semibold mb-4"
          >
            Why Invite-Only
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2, duration: 0.4 }}
            className="font-body text-white/60 mb-16 text-lg"
          >
            Quality over quantity. Always.
          </motion.p>
          
          {/* Reasons with bounce-in effect and glassmorphic cards */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {reasons.map((reason, index) => (
              <motion.div
                key={reason.title}
                initial={{ 
                  opacity: 0, 
                  y: 80, 
                  scale: 0.7,
                }}
                animate={isInView ? { 
                  opacity: 1, 
                  y: 0, 
                  scale: 1,
                } : {}}
                transition={{ 
                  duration: 0.5, 
                  delay: 0.25 + index * 0.1,
                  type: "spring",
                  stiffness: 350,
                  damping: 25,
                }}
                whileHover={{ 
                  scale: 1.05, 
                  y: -8,
                  transition: { duration: 0.25, type: "spring", stiffness: 400 } 
                }}
                className="flex flex-col items-center group bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6"
              >
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={isInView ? { scale: 1, rotate: 0 } : {}}
                  transition={{
                    type: "spring",
                    stiffness: 400,
                    damping: 12,
                    delay: 0.35 + index * 0.1,
                  }}
                  whileHover={{ 
                    rotate: [0, -20, 20, 0],
                    scale: 1.25
                  }}
                  className="relative"
                >
                  {/* Metallic glow ring */}
                  <motion.div
                    className="absolute inset-0 rounded-full blur-xl scale-[2] opacity-0 group-hover:opacity-100"
                    style={{
                      background: "radial-gradient(circle, hsl(0 75% 50% / 0.4) 0%, transparent 70%)",
                    }}
                    transition={{ duration: 0.3 }}
                  />
                  <motion.div
                    className="relative z-10"
                    animate={{
                      scale: [1, 1.12, 1],
                      rotate: [0, 6, -6, 0],
                    }}
                    transition={{
                      duration: 2.8,
                      repeat: Infinity,
                      ease: "easeInOut",
                      delay: 1.2 + index * 0.6,
                    }}
                  >
                    <reason.icon size={32} className="text-primary mb-4" />
                  </motion.div>
                </motion.div>
                <h3 className="font-display text-xl font-medium mb-1">
                  {reason.countUp ? (
                    <>
                      <CountUpNumber target={reason.countUp} isInView={isInView} /> seats
                    </>
                  ) : (
                    reason.title
                  )}
                </h3>
                <p className="font-body text-sm text-white/60">
                  {reason.description}
                </p>
              </motion.div>
            ))}
          </div>
          
          {/* Warning badge with dramatic multi-ring pulse */}
          <motion.div
            initial={{ opacity: 0, scale: 0.6, y: 40 }}
            animate={isInView ? { opacity: 1, scale: 1, y: 0 } : {}}
            transition={{ 
              duration: 0.5, 
              delay: 0.7, 
              type: "spring",
              stiffness: 250
            }}
            whileHover={{ scale: 1.05 }}
            className="inline-block px-8 py-4 rounded-full border border-white/20 bg-white/5 relative overflow-hidden backdrop-blur-sm"
          >
            {/* Multi-ring pulse */}
            {[...Array(4)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute inset-0 rounded-full border-2 border-primary/50"
                animate={{
                  scale: [1, 1.6 + i * 0.25],
                  opacity: [0.5, 0],
                }}
                transition={{ 
                  duration: 1.8, 
                  repeat: Infinity,
                  delay: i * 0.3,
                  ease: "easeOut"
                }}
              />
            ))}
            <p className="font-display text-base md:text-lg text-white relative z-10 tracking-wide">
              <span className="font-normal italic text-white/80">Not everyone</span>{" "}
              <span className="font-semibold">on the list</span>{" "}
              <span className="font-normal italic text-white/80">gets in.</span>
            </p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
