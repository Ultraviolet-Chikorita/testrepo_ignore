import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Check, Sparkles } from "lucide-react";

interface ConfirmationScreenProps {
  queuePosition: number;
  onUnlockPriority: () => void;
}

export function ConfirmationScreen({
  queuePosition,
  onUnlockPriority,
}: ConfirmationScreenProps) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 py-20">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6 }}
        className="max-w-md w-full text-center"
      >
        {/* Success icon */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2, type: "spring" }}
          className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary/10 mb-8"
        >
          <Check className="w-10 h-10 text-primary" strokeWidth={3} />
        </motion.div>

        {/* Title */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="font-display text-4xl md:text-5xl font-semibold mb-4"
        >
          You're on the list.
        </motion.h1>

        {/* Queue position */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-8"
        >
          <p className="font-body text-muted-foreground mb-2">
            Your current position
          </p>
          <p className="font-display text-5xl md:text-6xl font-bold metallic-heart">
            #{queuePosition}
          </p>
        </motion.div>

        {/* Wave system explanation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-secondary/50 rounded-2xl p-6 mb-8"
        >
          <p className="font-body text-sm text-muted-foreground leading-relaxed">
            <span className="font-medium text-foreground">How it works:</span>{" "}
            We have 250 seats. Invites go out in waves based on queue position.
            The higher you are, the sooner you hear from us.
          </p>
        </motion.div>

        {/* Priority unlock CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Button
            onClick={onUnlockPriority}
            size="lg"
            className="metallic-bg btn-shimmer text-primary-foreground font-body text-lg px-10 py-6 rounded-full shadow-lg group"
          >
            <Sparkles className="w-5 h-5 mr-2 group-hover:animate-pulse" />
            UNLOCK PRIORITY ACCESS
          </Button>

          <p className="font-body text-xs text-muted-foreground mt-4">
            Answer a few quick questions to move up the queue
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
}
