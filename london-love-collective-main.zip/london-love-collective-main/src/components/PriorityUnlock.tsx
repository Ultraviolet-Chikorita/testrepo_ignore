import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronRight, Instagram, Sparkles, Heart } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const interestCategories = {
  music: [
    "Techno/House",
    "R&B/Soul",
    "Hip Hop",
    "Pop",
    "Rock/Indie",
    "Jazz/Classical",
    "Afrobeats",
    "Latin",
  ],
  vibes: [
    "Club nights",
    "Cocktail bars",
    "House parties",
    "Gigs/Concerts",
    "Pub quizzes",
    "Art exhibitions",
    "Food markets",
    "Rooftop bars",
  ],
  hobbies: [
    "Gym/Fitness",
    "Travel",
    "Photography",
    "Reading",
    "Gaming",
    "Cooking",
    "Sports",
    "Art/Design",
  ],
  dating: [
    "Looking for something serious",
    "Open to anything",
    "Just here for fun",
    "Here for the chaos",
  ],
};

const quizQuestions = [
  {
    question: "Your ideal first date?",
    options: [
      "Rooftop drinks at sunset",
      "Hole-in-the-wall restaurant",
      "Art gallery then cocktails",
      "Spontaneous adventure",
    ],
  },
  {
    question: "Biggest dating ick?",
    options: [
      "Bad texters",
      "Can't hold a conversation",
      "Too much too soon",
      "Main character syndrome",
    ],
  },
  {
    question: "How do you flirt?",
    options: [
      "Witty banter",
      "Eye contact and smiles",
      "Deep conversation",
      "I panic and word vomit",
    ],
  },
];

interface PriorityUnlockProps {
  signupId: string;
  onComplete: (newPosition: number) => void;
}

export function PriorityUnlock({ signupId, onComplete }: PriorityUnlockProps) {
  const [step, setStep] = useState(0);
  const [instagram, setInstagram] = useState("");
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const totalSteps = 3;

  const toggleInterest = (interest: string) => {
    setSelectedInterests((prev) =>
      prev.includes(interest)
        ? prev.filter((i) => i !== interest)
        : prev.length < 8
        ? [...prev, interest]
        : prev
    );
  };

  const handleQuizAnswer = (questionIndex: number, answer: string) => {
    setQuizAnswers((prev) => ({ ...prev, [questionIndex]: answer }));
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);

    try {
      // Use secure RPC function to save priority responses
      const { data: result, error } = await supabase.rpc("save_priority_response", {
        p_signup_id: signupId,
        p_instagram_handle: instagram.replace("@", "").trim() || null,
        p_interests: selectedInterests,
        p_quiz_answers: quizAnswers,
      });

      if (error) throw error;

      // Check if the function returned an error
      if (result && typeof result === 'object' && 'error' in result) {
        throw new Error((result as { error: string }).error);
      }

      // Calculate new position (for demo, reduce by 20-50)
      const reduction = Math.floor(Math.random() * 30) + 20;
      const newPosition = Math.max(1, 100 - reduction);

      onComplete(newPosition);
    } catch (error) {
      console.error("Error saving priority responses:", error);
    }

    setIsSubmitting(false);
  };

  const canProceed = () => {
    if (step === 0) return instagram.length >= 2;
    if (step === 1) return selectedInterests.length >= 3;
    if (step === 2) return Object.keys(quizAnswers).length === quizQuestions.length;
    return false;
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 py-20">
      <div className="max-w-lg w-full">
        {/* Progress indicator */}
        <div className="flex justify-center gap-2 mb-8">
          {Array.from({ length: totalSteps }).map((_, i) => (
            <div
              key={i}
              className={`h-1.5 w-12 rounded-full transition-colors ${
                i <= step ? "bg-primary" : "bg-border"
              }`}
            />
          ))}
        </div>

        <AnimatePresence mode="wait">
          {/* Step 0: Instagram */}
          {step === 0 && (
            <motion.div
              key="instagram"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="text-center"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <Instagram className="w-8 h-8 text-primary" />
              </div>

              <h2 className="font-display text-3xl font-semibold mb-3">
                What's your Instagram?
              </h2>
              <p className="font-body text-muted-foreground mb-8">
                We use this for matching & verification
              </p>

              <div className="max-w-xs mx-auto">
                <Input
                  value={instagram}
                  onChange={(e) => setInstagram(e.target.value)}
                  placeholder="@yourhandle"
                  className="h-14 text-center text-lg font-body"
                />
              </div>
            </motion.div>
          )}

          {/* Step 1: Interests */}
          {step === 1 && (
            <motion.div
              key="interests"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <div className="text-center mb-8">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                  <Sparkles className="w-8 h-8 text-primary" />
                </div>

                <h2 className="font-display text-3xl font-semibold mb-3">
                  What are you into?
                </h2>
                <p className="font-body text-muted-foreground">
                  Select 3-8 things that vibe with you
                </p>
              </div>

              <div className="space-y-6">
                {Object.entries(interestCategories).map(([category, interests]) => (
                  <div key={category}>
                    <p className="font-body text-xs text-muted-foreground uppercase tracking-wider mb-3">
                      {category === "vibes" ? "Going out" : category}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {interests.map((interest) => (
                        <button
                          key={interest}
                          onClick={() => toggleInterest(interest)}
                          className={`px-4 py-2 rounded-full text-sm font-body transition-all ${
                            selectedInterests.includes(interest)
                              ? "bg-primary text-primary-foreground"
                              : "bg-secondary text-muted-foreground hover:bg-secondary/80"
                          }`}
                        >
                          {interest}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <p className="text-center font-body text-sm text-muted-foreground mt-6">
                {selectedInterests.length}/8 selected
              </p>
            </motion.div>
          )}

          {/* Step 2: Quiz */}
          {step === 2 && (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <div className="text-center mb-8">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                  <Heart className="w-8 h-8 text-primary fill-primary" />
                </div>

                <h2 className="font-display text-3xl font-semibold mb-3">
                  Cupid Check ✓
                </h2>
                <p className="font-body text-muted-foreground">
                  Quick personality questions
                </p>
              </div>

              <div className="space-y-8">
                {quizQuestions.map((q, qIndex) => (
                  <div key={qIndex}>
                    <p className="font-display text-lg font-medium mb-4">
                      {q.question}
                    </p>
                    <div className="grid grid-cols-2 gap-3">
                      {q.options.map((option) => (
                        <button
                          key={option}
                          onClick={() => handleQuizAnswer(qIndex, option)}
                          className={`p-4 rounded-xl text-sm font-body text-left transition-all ${
                            quizAnswers[qIndex] === option
                              ? "bg-primary text-primary-foreground"
                              : "bg-secondary text-muted-foreground hover:bg-secondary/80"
                          }`}
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Navigation */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="flex justify-between mt-10"
        >
          {step > 0 ? (
            <Button
              variant="ghost"
              onClick={() => setStep((s) => s - 1)}
              className="font-display text-lg tracking-wide"
            >
              Back
            </Button>
          ) : (
            <div />
          )}

          <Button
            onClick={() => {
              if (step < totalSteps - 1) {
                setStep((s) => s + 1);
              } else {
                handleSubmit();
              }
            }}
            disabled={!canProceed() || isSubmitting}
            className="metallic-bg btn-shimmer text-primary-foreground font-display text-lg tracking-wider px-8 rounded-full"
          >
            {isSubmitting ? (
              "Saving..."
            ) : step === totalSteps - 1 ? (
              "Complete"
            ) : (
              <>
                Continue
                <ChevronRight className="w-4 h-4 ml-1" />
              </>
            )}
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
