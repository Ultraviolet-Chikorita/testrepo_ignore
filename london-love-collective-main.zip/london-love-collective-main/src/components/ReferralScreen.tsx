import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Copy, MessageCircle, Share2, Check, Users } from "lucide-react";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

interface ReferralScreenProps {
  referralCode: string;
  queuePosition: number;
  signupId: string;
}

export function ReferralScreen({
  referralCode,
  queuePosition,
  signupId,
}: ReferralScreenProps) {
  const [copied, setCopied] = useState(false);
  const [referralCount, setReferralCount] = useState(0);

  const referralLink = `${window.location.origin}?ref=${referralCode}`;

  useEffect(() => {
    // Fetch referral count via secure RPC function
    const fetchReferrals = async () => {
      const { data: count } = await supabase.rpc('get_referral_count', {
        p_signup_id: signupId
      });

      setReferralCount(count || 0);
    };

    fetchReferrals();
  }, [signupId]);

  const copyLink = async () => {
    await navigator.clipboard.writeText(referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const shareWhatsApp = () => {
    const text = encodeURIComponent(
      `I just joined the waitlist for London's biggest Valentine's dating show 💕 You should too! Use my code ${referralCode} and we both move up the queue: ${referralLink}`
    );
    window.open(`https://wa.me/?text=${text}`, "_blank");
  };

  const shareNative = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Valentine's Dating Show",
          text: `Join me at London's biggest Valentine's dating show! Use my code ${referralCode}`,
          url: referralLink,
        });
      } catch (err) {
        // User cancelled or error
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 py-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-md w-full text-center"
      >
        {/* Header */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring" }}
          className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary/10 mb-6"
        >
          <Users className="w-10 h-10 text-primary" />
        </motion.div>

        <h1 className="font-display text-3xl md:text-4xl font-semibold mb-3">
          Move Up the Queue
        </h1>

        <p className="font-body text-muted-foreground mb-8">
          Each friend who joins with your code bumps you both up
        </p>

        {/* Current position */}
        <div className="bg-secondary/50 rounded-2xl p-6 mb-8">
          <p className="font-body text-sm text-muted-foreground mb-2">
            Your position
          </p>
          <p className="font-display text-4xl font-bold metallic-heart mb-4">
            #{queuePosition}
          </p>

          {referralCount > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center justify-center gap-2 text-primary"
            >
              <Check className="w-4 h-4" />
              <span className="font-body text-sm">
                {referralCount} friend{referralCount > 1 ? "s" : ""} joined!
              </span>
            </motion.div>
          )}
        </div>

        {/* Referral code */}
        <div className="mb-8">
          <p className="font-body text-xs text-muted-foreground uppercase tracking-wider mb-3">
            Your referral code
          </p>
          <div className="flex items-center gap-2 max-w-xs mx-auto">
            <Input
              value={referralCode}
              readOnly
              className="h-14 text-center text-2xl font-display font-bold tracking-widest bg-background"
            />
            <Button
              variant="outline"
              size="icon"
              onClick={copyLink}
              className="h-14 w-14 shrink-0"
            >
              {copied ? (
                <Check className="w-5 h-5 text-primary" />
              ) : (
                <Copy className="w-5 h-5" />
              )}
            </Button>
          </div>
        </div>

        {/* Share buttons */}
        <div className="flex flex-col gap-3">
          <Button
            onClick={shareWhatsApp}
            className="w-full h-14 bg-[#25D366] hover:bg-[#20BD5A] text-white font-display text-xl tracking-wide rounded-full"
          >
            <MessageCircle className="w-5 h-5 mr-2" />
            Share on WhatsApp
          </Button>

          {"share" in navigator && (
            <Button
              onClick={shareNative}
              variant="outline"
              className="w-full h-14 font-display text-xl tracking-wide rounded-full"
            >
              <Share2 className="w-5 h-5 mr-2" />
              Share Link
            </Button>
          )}

          <button
            onClick={copyLink}
            className="font-body text-sm text-muted-foreground hover:text-primary transition-colors"
          >
            {copied ? "Copied!" : "Copy link to clipboard"}
          </button>
        </div>

        {/* Info */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="font-body text-xs text-muted-foreground mt-8"
        >
          We'll text you when invites drop. Keep checking back!
        </motion.p>
      </motion.div>
    </div>
  );
}
