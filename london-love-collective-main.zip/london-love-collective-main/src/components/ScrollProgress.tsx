import { motion, useScroll, useSpring, useTransform } from "framer-motion";
import { MetallicHeart } from "./MetallicHeart";

export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  
  // Smooth spring animation for progress
  const scaleY = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001,
  });
  
  // Calculate position for the heart indicator (percentage of viewport height)
  const heartTop = useTransform(scrollYProgress, [0, 1], [8, 92]);
  
  // Glow intensity based on scroll progress
  const glowOpacity = useTransform(scrollYProgress, [0, 0.5, 1], [0.4, 0.8, 0.4]);

  return (
    <div className="fixed right-4 top-1/2 -translate-y-1/2 z-50 hidden md:flex flex-col items-center h-32">
      {/* Progress track background */}
      <div className="relative h-full w-1 rounded-full bg-border/30 overflow-hidden">
        {/* Metallic gradient progress fill */}
        <motion.div
          className="absolute bottom-0 left-0 right-0 origin-bottom rounded-full"
          style={{
            scaleY,
            background: "linear-gradient(to top, hsl(0 75% 28%), hsl(0 80% 40%), hsl(0 75% 28%))",
          }}
        />
        
        {/* Glow effect overlay */}
        <motion.div
          className="absolute inset-0 rounded-full blur-sm pointer-events-none"
          style={{
            opacity: glowOpacity,
            background: "linear-gradient(to top, hsl(0 75% 40% / 0.5), hsl(0 80% 50% / 0.3))",
          }}
        />
      </div>
      
      {/* Metallic heart indicator positioned along the track */}
      <motion.div
        className="absolute -left-[6px]"
        style={{ 
          top: useTransform(scaleY, (value) => `${value * 100}%`),
        }}
      >
        <motion.div
          animate={{
            scale: [1, 1.15, 1],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        >
          <MetallicHeart size={18} shimmerDelay={0} />
        </motion.div>
      </motion.div>
    </div>
  );
}
