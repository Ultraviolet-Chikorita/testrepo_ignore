import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { Zap, Eye, Flame, Sparkles, Trophy } from "lucide-react";

const games = [
  {
    icon: Sparkles,
    title: "Find your match in 5 minutes",
    description: "AI + lock & key. Panic included.",
  },
  {
    icon: Eye,
    title: "Blind date Q&A",
    description: "Crowd votes: the room decides who stays.",
  },
  {
    icon: Zap,
    title: "Pop the Balloon",
    description: "Pick-up line battle. Tap outs.",
  },
  {
    icon: Flame,
    title: "Unfiltered Round (opt-in)",
    description: "No details. Just know it's the clip everyone posts.",
  },
  {
    icon: Trophy,
    title: "Finals",
    description: "Paid, filmed date for the winning couple.",
  },
];

export function GamesSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });
  
  const backgroundY = useTransform(scrollYProgress, [0, 1], [80, -80]);
  const cardsY = useTransform(scrollYProgress, [0, 0.5, 1], [40, 0, -30]);
  const taglineScale = useTransform(scrollYProgress, [0.5, 0.7, 0.9], [0.95, 1.03, 1]);
  const backgroundRotate = useTransform(scrollYProgress, [0, 1], [0, 15]);

  return (
    <section ref={ref} className="py-12 md:py-16 relative overflow-hidden bg-secondary/20">
      {/* Animated background gradient with parallax */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        initial={{ opacity: 0 }}
        animate={isInView ? { opacity: 1 } : {}}
        transition={{ duration: 0.8 }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-background via-secondary/20 to-background" />
        <motion.div
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/8 rounded-full blur-3xl"
          style={{ y: backgroundY, rotate: backgroundRotate }}
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.4, 0.7, 0.4],
          }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary/8 rounded-full blur-3xl"
          style={{ y: backgroundY, rotate: backgroundRotate }}
          animate={{
            scale: [1.3, 1, 1.3],
            opacity: [0.6, 0.4, 0.6],
          }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        />
        {/* Additional floating orbs for depth */}
        <motion.div
          className="absolute top-1/2 left-10 w-48 h-48 bg-primary/5 rounded-full blur-2xl"
          style={{ y: useTransform(scrollYProgress, [0, 1], [0, -120]) }}
        />
        <motion.div
          className="absolute bottom-1/3 right-20 w-36 h-36 bg-primary/6 rounded-full blur-2xl"
          style={{ y: useTransform(scrollYProgress, [0, 1], [0, -80]) }}
        />
      </motion.div>
      
      <div className="container px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50, filter: "blur(10px)" }}
          animate={isInView ? { opacity: 1, y: 0, filter: "blur(0px)" } : {}}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="text-center mb-16"
        >
          <motion.h2
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ 
              duration: 0.5, 
              type: "spring", 
              stiffness: 200,
              damping: 20
            }}
            className="font-display text-3xl md:text-5xl font-semibold mb-4"
          >
            The Programme
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2, duration: 0.4 }}
            className="font-body text-muted-foreground text-lg"
          >
            Five rounds. Zero boredom.
          </motion.p>
        </motion.div>
        
        {/* Games grid with waterfall cascade effect */}
        <motion.div 
          className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4 max-w-6xl mx-auto mb-16"
          style={{ y: cardsY }}
        >
          {games.map((game, index) => (
            <motion.div
              key={game.title}
              initial={{ 
                opacity: 0, 
                y: 80,
                scale: 0.7,
                rotateX: -20,
              }}
              animate={isInView ? { 
                opacity: 1, 
                y: 0,
                scale: 1,
                rotateX: 0,
              } : {}}
              transition={{
                duration: 0.5,
                delay: 0.15 + index * 0.07,
                type: "spring",
                stiffness: 400,
                damping: 25,
              }}
              whileHover={{
                y: -16,
                scale: 1.06,
                rotateY: 5,
                transition: { duration: 0.25, type: "spring", stiffness: 400 },
              }}
              className="group relative"
              style={{ perspective: "1000px" }}
            >
              <motion.div
                className="h-full p-6 rounded-2xl bg-white/70 dark:bg-white/10 backdrop-blur-md border border-white/40 shadow-lg shadow-black/5 transition-all duration-300 relative overflow-hidden"
                whileHover={{
                  borderColor: "hsl(0 75% 28% / 0.5)",
                  boxShadow: "0 35px 70px -15px hsl(0 75% 28% / 0.25)",
                }}
              >
                {/* Metallic ring glow on reveal */}
                <motion.div
                  className="absolute inset-0 rounded-2xl pointer-events-none"
                  initial={{ boxShadow: "inset 0 0 0 0 hsl(0 75% 40% / 0)" }}
                  animate={isInView ? { 
                    boxShadow: [
                      "inset 0 0 0 0 hsl(0 75% 40% / 0)",
                      "inset 0 0 40px 3px hsl(0 75% 40% / 0.2)",
                      "inset 0 0 0 0 hsl(0 75% 40% / 0)"
                    ]
                  } : {}}
                  transition={{ 
                    duration: 0.6, 
                    delay: 0.3 + index * 0.08,
                    ease: "easeOut"
                  }}
                />
                
                {/* Shimmer effect on hover */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                  initial={{ x: "-100%" }}
                  whileHover={{ x: "100%" }}
                  transition={{ duration: 0.5 }}
                />
                
                {/* Glow effect */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-t from-primary/15 to-transparent opacity-0 group-hover:opacity-100"
                  transition={{ duration: 0.25 }}
                />
                
                <div className="flex flex-col items-center text-center relative z-10">
                  <motion.div
                    className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors relative"
                    initial={{ scale: 0, rotate: -180 }}
                    animate={isInView ? { scale: 1, rotate: 0 } : {}}
                    transition={{
                      type: "spring",
                      stiffness: 400,
                      damping: 15,
                      delay: 0.25 + index * 0.07,
                    }}
                    whileHover={{ rotate: 360, scale: 1.15 }}
                  >
                    {/* Icon metallic glow ring */}
                    <motion.div
                      className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100"
                      style={{
                        background: "radial-gradient(circle, hsl(0 75% 45% / 0.3) 0%, transparent 70%)",
                      }}
                      transition={{ duration: 0.3 }}
                    />
                    <motion.div
                      className="relative z-10"
                      animate={{
                        scale: [1, 1.15, 1],
                        rotate: [0, 8, -8, 0],
                      }}
                      transition={{
                        duration: 2.5,
                        repeat: Infinity,
                        ease: "easeInOut",
                        delay: 1.5 + index * 0.5,
                      }}
                    >
                      <game.icon size={24} className="text-primary" />
                    </motion.div>
                  </motion.div>
                  <h3 className="font-display text-lg font-medium mb-2">
                    {game.title}
                  </h3>
                  <p className="font-body text-sm text-muted-foreground">
                    {game.description}
                  </p>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </motion.div>
        
        {/* Tagline with snappy reveal and scroll scale */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.7 }}
          className="text-center font-display text-xl md:text-2xl text-muted-foreground italic"
          style={{ scale: taglineScale }}
        >
          <motion.span
            initial={{ opacity: 0, x: -30, filter: "blur(4px)" }}
            animate={isInView ? { opacity: 1, x: 0, filter: "blur(0px)" } : {}}
            transition={{ delay: 0.75, duration: 0.35, type: "spring", stiffness: 300 }}
          >
            Fast.
          </motion.span>{" "}
          <motion.span
            initial={{ opacity: 0, x: -30, filter: "blur(4px)" }}
            animate={isInView ? { opacity: 1, x: 0, filter: "blur(0px)" } : {}}
            transition={{ delay: 0.85, duration: 0.35, type: "spring", stiffness: 300 }}
          >
            Funny.
          </motion.span>{" "}
          <motion.span
            initial={{ opacity: 0, scale: 0.8, filter: "blur(6px)" }}
            animate={isInView ? { opacity: 1, scale: 1, filter: "blur(0px)" } : {}}
            transition={{ delay: 0.95, duration: 0.4, type: "spring", stiffness: 250 }}
            className="text-foreground not-italic font-medium"
          >
            Slightly unhinged.
          </motion.span>
        </motion.p>
      </div>
    </section>
  );
}
