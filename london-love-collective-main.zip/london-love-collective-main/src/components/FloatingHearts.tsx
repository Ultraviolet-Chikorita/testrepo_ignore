import { motion } from "framer-motion";
import { Heart } from "lucide-react";
import { useMemo } from "react";

interface FallingHeart {
  id: number;
  initialX: number;
  size: number;
  opacity: number;
  delay: number;
  duration: number;
  swayAmplitude: number;
  swayFrequency: number;
  rotationDirection: number;
  driftDirection: number;
}

// Generate hearts with unique natural motion profiles
function generateHearts(count: number): FallingHeart[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i,
    initialX: 5 + Math.random() * 90, // Keep away from edges
    size: 10 + Math.random() * 12, // 10-22px
    opacity: 0.12 + Math.random() * 0.18, // 0.12-0.30 - very subtle
    delay: Math.random() * 15, // More staggered starts
    duration: 18 + Math.random() * 12, // 18-30s - slower, more feathery
    swayAmplitude: 20 + Math.random() * 50, // How far it sways
    swayFrequency: 2 + Math.random() * 3, // How many sway cycles
    rotationDirection: Math.random() > 0.5 ? 1 : -1, // Random spin direction
    driftDirection: Math.random() > 0.5 ? 1 : -1, // Drift left or right overall
  }));
}

function FallingHeart({ heart }: { heart: FallingHeart }) {
  // Generate unique sway pattern based on frequency
  const swayKeyframes = useMemo(() => {
    const points: number[] = [0];
    const steps = Math.floor(heart.swayFrequency * 2);
    for (let i = 1; i <= steps; i++) {
      const direction = i % 2 === 1 ? 1 : -1;
      const damping = 1 - (i / steps) * 0.3; // Reduce amplitude over time
      points.push(direction * heart.swayAmplitude * damping * (0.6 + Math.random() * 0.4));
    }
    points.push(heart.driftDirection * 20); // End with slight drift
    return points;
  }, [heart]);

  // Generate rotation keyframes
  const rotationKeyframes = useMemo(() => {
    const baseRotation = 15 + Math.random() * 25;
    return [
      0,
      heart.rotationDirection * baseRotation,
      heart.rotationDirection * -baseRotation * 0.7,
      heart.rotationDirection * baseRotation * 0.5,
      heart.rotationDirection * -baseRotation * 0.3,
      heart.rotationDirection * 10,
    ];
  }, [heart]);

  // Subtle scale breathing
  const scaleKeyframes = [0.8, 1, 0.95, 1.05, 0.9, 1];

  return (
    <motion.div
      className="absolute pointer-events-none"
      style={{
        left: `${heart.initialX}%`,
        top: -40,
      }}
      initial={{ 
        y: -40,
        opacity: 0,
      }}
      animate={{
        y: ["0vh", "105vh"],
        opacity: [0, heart.opacity * 0.5, heart.opacity, heart.opacity, heart.opacity * 0.7, 0],
      }}
      transition={{
        duration: heart.duration,
        delay: heart.delay,
        repeat: Infinity,
        ease: [0.25, 0.1, 0.25, 1], // Custom bezier for natural fall
      }}
    >
      {/* Separate motion for sway - creates layered, organic movement */}
      <motion.div
        animate={{
          x: swayKeyframes,
        }}
        transition={{
          duration: heart.duration,
          delay: heart.delay,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        {/* Separate motion for rotation and scale - flutter effect */}
        <motion.div
          animate={{
            rotate: rotationKeyframes,
            scale: scaleKeyframes,
          }}
          transition={{
            duration: heart.duration * 0.8,
            delay: heart.delay,
            repeat: Infinity,
            ease: [0.37, 0, 0.63, 1], // Smooth ease for flutter
          }}
        >
          <Heart 
            size={heart.size} 
            className="text-primary/80 fill-primary/70"
            style={{
              filter: `drop-shadow(0 1px 2px hsl(0 75% 50% / 0.15))`,
            }}
          />
        </motion.div>
      </motion.div>
    </motion.div>
  );
}

export function FloatingHearts() {
  // Slightly increased density (22 hearts)
  const hearts = useMemo(() => generateHearts(22), []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-10">
      {hearts.map((heart) => (
        <FallingHeart key={heart.id} heart={heart} />
      ))}
    </div>
  );
}
