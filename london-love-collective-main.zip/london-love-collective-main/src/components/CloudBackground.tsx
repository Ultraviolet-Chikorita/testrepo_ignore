import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";

export function CloudBackground() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll();
  
  // Slower parallax for clouds (they move less than content)
  const cloudY1 = useTransform(scrollYProgress, [0, 1], [0, -100]);
  const cloudY2 = useTransform(scrollYProgress, [0, 1], [0, -150]);
  const cloudY3 = useTransform(scrollYProgress, [0, 1], [0, -80]);
  const cloudX1 = useTransform(scrollYProgress, [0, 1], [0, 50]);
  const cloudX2 = useTransform(scrollYProgress, [0, 1], [0, -30]);

  return (
    <div ref={ref} className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Large background cloud - top left - more visible cotton-like */}
      <motion.div
        className="absolute -top-20 -left-40 w-[700px] h-[350px]"
        style={{ y: cloudY1, x: cloudX1 }}
        animate={{
          scale: [1, 1.08, 1],
        }}
        transition={{
          duration: 18,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        {/* Multi-layer cloud for cotton effect */}
        <div 
          className="absolute inset-0"
          style={{
            background: "radial-gradient(ellipse at 40% 40%, hsl(30 20% 98% / 0.7) 0%, hsl(30 15% 96% / 0.4) 40%, transparent 70%)",
            filter: "blur(35px)",
          }}
        />
        <div 
          className="absolute inset-0"
          style={{
            background: "radial-gradient(ellipse at 60% 50%, hsl(30 20% 99% / 0.5) 0%, transparent 60%)",
            filter: "blur(25px)",
          }}
        />
      </motion.div>
      
      {/* Right side cloud - more defined edges */}
      <motion.div
        className="absolute top-1/4 -right-32 w-[500px] h-[300px]"
        style={{ y: cloudY2, x: cloudX2 }}
        animate={{
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 14,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 2,
        }}
      >
        <div 
          className="absolute inset-0"
          style={{
            background: "radial-gradient(ellipse at 30% 50%, hsl(30 20% 98% / 0.65) 0%, hsl(30 15% 95% / 0.35) 45%, transparent 70%)",
            filter: "blur(30px)",
          }}
        />
        <div 
          className="absolute inset-0"
          style={{
            background: "radial-gradient(ellipse at 50% 40%, hsl(30 20% 100% / 0.4) 0%, transparent 50%)",
            filter: "blur(20px)",
          }}
        />
      </motion.div>
      
      {/* Bottom cloud - large and fluffy */}
      <motion.div
        className="absolute bottom-0 left-1/4 w-[600px] h-[250px]"
        style={{ y: cloudY3 }}
        animate={{
          x: [0, 50, 0],
        }}
        transition={{
          duration: 16,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 4,
        }}
      >
        <div 
          className="absolute inset-0"
          style={{
            background: "radial-gradient(ellipse at 50% 60%, hsl(30 20% 98% / 0.6) 0%, hsl(30 15% 95% / 0.3) 50%, transparent 70%)",
            filter: "blur(40px)",
          }}
        />
      </motion.div>
      
      {/* Small accent cloud - mid left */}
      <motion.div
        className="absolute top-1/2 left-8 w-[250px] h-[120px]"
        style={{ y: cloudY2 }}
        animate={{
          y: [0, -20, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 3,
        }}
      >
        <div 
          className="absolute inset-0"
          style={{
            background: "radial-gradient(ellipse at center, hsl(30 20% 98% / 0.5) 0%, transparent 65%)",
            filter: "blur(20px)",
          }}
        />
      </motion.div>

      {/* Additional cloud - center right */}
      <motion.div
        className="absolute top-2/3 right-1/4 w-[400px] h-[200px]"
        style={{ y: cloudY1, x: cloudX2 }}
        animate={{
          scale: [1, 1.05, 1],
        }}
        transition={{
          duration: 14,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 6,
        }}
      >
        <div 
          className="absolute inset-0"
          style={{
            background: "radial-gradient(ellipse at 40% 50%, hsl(30 20% 98% / 0.45) 0%, transparent 60%)",
            filter: "blur(30px)",
          }}
        />
      </motion.div>

      {/* Top center wispy cloud */}
      <motion.div
        className="absolute top-16 left-1/2 -translate-x-1/2 w-[350px] h-[100px]"
        style={{ y: cloudY3 }}
        animate={{
          x: [-20, 20, -20],
          opacity: [0.4, 0.6, 0.4],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        <div 
          className="absolute inset-0"
          style={{
            background: "radial-gradient(ellipse at center, hsl(30 20% 99% / 0.5) 0%, transparent 60%)",
            filter: "blur(25px)",
          }}
        />
      </motion.div>
    </div>
  );
}
