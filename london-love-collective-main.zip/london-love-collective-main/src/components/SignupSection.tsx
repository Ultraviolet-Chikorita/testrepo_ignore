import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { useRef, forwardRef } from "react";
import { Heart } from "lucide-react";
import { SignupForm } from "./SignupForm";
interface SignupSectionProps {
  onSuccess: (data: {
    id: string;
    referralCode: string;
    queuePosition: number;
  }) => void;
  initialReferralCode?: string;
}
export const SignupSection = forwardRef<HTMLElement, SignupSectionProps>(({
  onSuccess,
  initialReferralCode
}, ref) => {
  const inViewRef = useRef(null);
  const isInView = useInView(inViewRef, {
    once: true,
    margin: "-100px"
  });
  const {
    scrollYProgress
  } = useScroll({
    target: inViewRef,
    offset: ["start end", "end start"]
  });
  const backgroundY = useTransform(scrollYProgress, [0, 1], [60, -60]);
  const cardY = useTransform(scrollYProgress, [0, 0.5, 1], [40, 0, -20]);
  return <section ref={ref} id="signup" className="py-12 md:py-16 relative overflow-hidden">
        {/* Animated gradient background with parallax */}
        <motion.div className="absolute inset-0 pointer-events-none" initial={{
      opacity: 0
    }} animate={isInView ? {
      opacity: 1
    } : {}} transition={{
      duration: 0.8
    }}>
          <div className="absolute inset-0 bg-gradient-to-b from-secondary/30 via-background to-background" />
          <motion.div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-primary/8 rounded-full blur-3xl" style={{
        y: backgroundY
      }} animate={{
        scale: [1, 1.2, 1],
        opacity: [0.4, 0.6, 0.4]
      }} transition={{
        duration: 5,
        repeat: Infinity,
        ease: "easeInOut"
      }} />
          
          {/* Additional floating orbs */}
          <motion.div className="absolute bottom-1/4 left-1/4 w-56 h-56 bg-primary/8 rounded-full blur-2xl" style={{
        y: backgroundY
      }} animate={{
        x: [0, 40, 0],
        opacity: [0.3, 0.5, 0.3]
      }} transition={{
        duration: 7,
        repeat: Infinity,
        ease: "easeInOut"
      }} />
        </motion.div>

        <div className="container px-4 relative z-10" ref={inViewRef}>
          <motion.div initial={{
        opacity: 0,
        y: 60,
        filter: "blur(10px)"
      }} animate={isInView ? {
        opacity: 1,
        y: 0,
        filter: "blur(0px)"
      } : {}} transition={{
        duration: 0.7,
        ease: [0.22, 1, 0.36, 1]
      }} className="max-w-md mx-auto">
            {/* Header with enhanced animations */}
            <div className="text-center mb-10">
              <motion.div initial={{
            scale: 0,
            rotate: -180,
            opacity: 0
          }} animate={isInView ? {
            scale: 1,
            rotate: 0,
            opacity: 1
          } : {}} transition={{
            duration: 0.6,
            delay: 0.15,
            type: "spring",
            stiffness: 200
          }} className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary/10 mb-6 relative">
              {/* Smooth pulsing rings - 2 rings for cleaner look */}
              {[...Array(2)].map((_, i) => <motion.div key={i} className="absolute inset-0 rounded-full border-2 border-red-500/40" animate={{
              scale: [1, 1.5 + i * 0.2],
              opacity: [0.6, 0.3, 0]
            }} transition={{
              duration: 3.5,
              repeat: Infinity,
              delay: i * 0.8,
              ease: "linear"
            }} />)}
                <motion.div animate={{
              scale: [1, 1.15, 1.05, 1.15, 1],
              y: [0, -3, 0, -2, 0]
            }} transition={{
              duration: 3.5,
              repeat: Infinity,
              ease: "easeInOut"
            }}>
                  <Heart size={36} className="text-red-500 fill-red-500" style={{
                filter: "drop-shadow(0 4px 12px rgba(239, 68, 68, 0.5))"
              }} />
                </motion.div>
              </motion.div>

              <motion.h2 initial={{
            opacity: 0,
            y: 30,
            scale: 0.9
          }} animate={isInView ? {
            opacity: 1,
            y: 0,
            scale: 1
          } : {}} transition={{
            delay: 0.25,
            duration: 0.5,
            type: "spring",
            stiffness: 200
          }} className="font-display text-3xl md:text-4xl font-semibold mb-3">
                Get on the List
              </motion.h2>
              <motion.p initial={{
            opacity: 0,
            y: 20
          }} animate={isInView ? {
            opacity: 1,
            y: 0
          } : {}} transition={{
            delay: 0.35,
            duration: 0.4
          }} className="text-muted-foreground font-serif">
                Invites drop in waves. Seats go fast.                 
              </motion.p>
            </div>

            {/* Form card with 3D lift effect */}
            <motion.div initial={{
          opacity: 0,
          y: 80,
          rotateX: -15,
          scale: 0.9
        }} animate={isInView ? {
          opacity: 1,
          y: 0,
          rotateX: 0,
          scale: 1
        } : {}} transition={{
          duration: 0.6,
          delay: 0.4,
          type: "spring",
          stiffness: 200,
          damping: 25
        }} whileHover={{
          y: -10,
          scale: 1.02,
          boxShadow: "0 40px 70px -15px hsl(0 75% 28% / 0.2)"
        }} className="bg-card border border-border rounded-2xl p-8 shadow-lg transition-shadow relative overflow-hidden" style={{
          perspective: "1000px",
          y: cardY as unknown as number
        }}>
              {/* Metallic ring glow on reveal */}
              <motion.div className="absolute inset-0 rounded-2xl pointer-events-none" initial={{
            boxShadow: "inset 0 0 0 0 hsl(0 75% 40% / 0)"
          }} animate={isInView ? {
            boxShadow: ["inset 0 0 0 0 hsl(0 75% 40% / 0)", "inset 0 0 50px 4px hsl(0 75% 40% / 0.15)", "inset 0 0 0 0 hsl(0 75% 40% / 0)"]
          } : {}} transition={{
            duration: 0.8,
            delay: 0.5,
            ease: "easeOut"
          }} />
              
              {/* Subtle gradient overlay on hover */}
              <motion.div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent opacity-0" whileHover={{
            opacity: 1
          }} transition={{
            duration: 0.3
          }} />
              
              <SignupForm onSuccess={onSuccess} initialReferralCode={initialReferralCode} />
            </motion.div>

            {/* Trust note with fade-in */}
            <motion.p initial={{
          opacity: 0,
          y: 20
        }} animate={isInView ? {
          opacity: 1,
          y: 0
        } : {}} transition={{
          duration: 0.5,
          delay: 0.65
        }} className="text-center text-xs text-muted-foreground mt-6 font-serif">
              Your info stays private. We only text about the event.
            </motion.p>
          </motion.div>
        </div>
      </section>;
});
SignupSection.displayName = "SignupSection";