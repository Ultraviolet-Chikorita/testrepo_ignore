import { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useSignup } from "@/hooks/useSignup";
import { Loader2, ChevronsUpDown, Check } from "lucide-react";
import { cn } from "@/lib/utils";

const universities = [
  "Imperial College London",
  "University College London (UCL)",
  "King's College London (KCL)",
  "London School of Economics (LSE)",
  "University of the Arts London (UAL)",
  "City, University of London",
  "Queen Mary University of London",
  "Goldsmiths, University of London",
  "University of Westminster",
  "SOAS University of London",
  "Royal Holloway, University of London",
  "Brunel University London",
  "Kingston University",
  "Middlesex University",
  "London Metropolitan University",
  "University of Greenwich",
  "Other London University",
];

const countryCodes = [
  { code: "+44", country: "UK", flag: "🇬🇧" },
  { code: "+1", country: "US/Canada", flag: "🇺🇸" },
  { code: "+91", country: "India", flag: "🇮🇳" },
  { code: "+86", country: "China", flag: "🇨🇳" },
  { code: "+49", country: "Germany", flag: "🇩🇪" },
  { code: "+33", country: "France", flag: "🇫🇷" },
  { code: "+39", country: "Italy", flag: "🇮🇹" },
  { code: "+34", country: "Spain", flag: "🇪🇸" },
  { code: "+31", country: "Netherlands", flag: "🇳🇱" },
  { code: "+32", country: "Belgium", flag: "🇧🇪" },
  { code: "+41", country: "Switzerland", flag: "🇨🇭" },
  { code: "+43", country: "Austria", flag: "🇦🇹" },
  { code: "+46", country: "Sweden", flag: "🇸🇪" },
  { code: "+47", country: "Norway", flag: "🇳🇴" },
  { code: "+45", country: "Denmark", flag: "🇩🇰" },
  { code: "+48", country: "Poland", flag: "🇵🇱" },
  { code: "+351", country: "Portugal", flag: "🇵🇹" },
  { code: "+353", country: "Ireland", flag: "🇮🇪" },
  { code: "+30", country: "Greece", flag: "🇬🇷" },
  { code: "+7", country: "Russia", flag: "🇷🇺" },
  { code: "+81", country: "Japan", flag: "🇯🇵" },
  { code: "+82", country: "South Korea", flag: "🇰🇷" },
  { code: "+61", country: "Australia", flag: "🇦🇺" },
  { code: "+64", country: "New Zealand", flag: "🇳🇿" },
  { code: "+65", country: "Singapore", flag: "🇸🇬" },
  { code: "+852", country: "Hong Kong", flag: "🇭🇰" },
  { code: "+971", country: "UAE", flag: "🇦🇪" },
  { code: "+966", country: "Saudi Arabia", flag: "🇸🇦" },
  { code: "+234", country: "Nigeria", flag: "🇳🇬" },
  { code: "+27", country: "South Africa", flag: "🇿🇦" },
  { code: "+55", country: "Brazil", flag: "🇧🇷" },
  { code: "+52", country: "Mexico", flag: "🇲🇽" },
  { code: "+92", country: "Pakistan", flag: "🇵🇰" },
  { code: "+880", country: "Bangladesh", flag: "🇧🇩" },
  { code: "+60", country: "Malaysia", flag: "🇲🇾" },
  { code: "+63", country: "Philippines", flag: "🇵🇭" },
  { code: "+66", country: "Thailand", flag: "🇹🇭" },
  { code: "+84", country: "Vietnam", flag: "🇻🇳" },
  { code: "+62", country: "Indonesia", flag: "🇮🇩" },
  { code: "+20", country: "Egypt", flag: "🇪🇬" },
];

const formSchema = z.object({
  firstName: z
    .string()
    .trim()
    .min(1, "Name is required")
    .max(50, "Name is too long"),
  university: z.string().min(1, "Please select your university"),
  countryCode: z.string().min(1, "Please select a country code"),
  phone: z
    .string()
    .trim()
    .min(6, "Please enter a valid phone number")
    .max(15, "Phone number is too long")
    .regex(/^[\d\s()-]+$/, "Please enter a valid phone number"),
  referralCode: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

interface SignupFormProps {
  onSuccess: (data: { id: string; referralCode: string; queuePosition: number }) => void;
  initialReferralCode?: string;
}

export function SignupForm({ onSuccess, initialReferralCode }: SignupFormProps) {
  const { signup, isLoading, error } = useSignup();
  const [showReferral, setShowReferral] = useState(!!initialReferralCode);

  const [countryCodeOpen, setCountryCodeOpen] = useState(false);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      firstName: "",
      university: "",
      countryCode: "+44",
      phone: "",
      referralCode: initialReferralCode || "",
    },
  });

  const onSubmit = async (data: FormData) => {
    const fullPhone = `${data.countryCode} ${data.phone}`;
    const result = await signup({
      firstName: data.firstName,
      university: data.university,
      phone: fullPhone,
      referralCode: data.referralCode,
    });

    if (result) {
      onSuccess(result);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="firstName"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="font-body text-sm text-muted-foreground uppercase tracking-wider">
                First Name
              </FormLabel>
              <FormControl>
                <Input
                  {...field}
                  placeholder="Your first name"
                  className="h-12 bg-background border-border focus:border-primary font-body"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="university"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="font-body text-sm text-muted-foreground uppercase tracking-wider">
                University
              </FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger className="h-12 bg-background border-border focus:border-primary font-body">
                    <SelectValue placeholder="Select your university" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {universities.map((uni) => (
                    <SelectItem key={uni} value={uni} className="font-body">
                      {uni}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="countryCode"
          render={({ field }) => (
            <FormItem className="flex flex-col">
              <FormLabel className="font-body text-sm text-muted-foreground uppercase tracking-wider">
                Phone Number
              </FormLabel>
              <div className="flex gap-2">
                <Popover open={countryCodeOpen} onOpenChange={setCountryCodeOpen}>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded={countryCodeOpen}
                        className="w-[120px] h-12 justify-between bg-background border-border hover:bg-accent font-body"
                      >
                        {field.value ? (
                          <>
                            <span className="mr-1">
                              {countryCodes.find((c) => c.code === field.value)?.flag}
                            </span>
                            {field.value}
                          </>
                        ) : (
                          "Code"
                        )}
                        <ChevronsUpDown className="ml-1 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-[240px] p-0 bg-popover border-border z-50">
                    <Command>
                      <CommandInput placeholder="Search country..." className="font-body" />
                      <CommandList>
                        <CommandEmpty>No country found.</CommandEmpty>
                        <CommandGroup className="max-h-[200px] overflow-y-auto">
                          {countryCodes.map((country) => (
                            <CommandItem
                              key={country.code}
                              value={`${country.country} ${country.code}`}
                              onSelect={() => {
                                field.onChange(country.code);
                                setCountryCodeOpen(false);
                              }}
                              className="font-body cursor-pointer"
                            >
                              <Check
                                className={cn(
                                  "mr-2 h-4 w-4",
                                  field.value === country.code ? "opacity-100" : "opacity-0"
                                )}
                              />
                              <span className="mr-2">{country.flag}</span>
                              <span className="flex-1">{country.country}</span>
                              <span className="text-muted-foreground">{country.code}</span>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
                
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field: phoneField }) => (
                    <FormControl>
                      <Input
                        {...phoneField}
                        type="tel"
                        placeholder="7XXX XXXXXX"
                        className="flex-1 h-12 bg-background border-border focus:border-primary font-body"
                      />
                    </FormControl>
                  )}
                />
              </div>
              <FormMessage />
            </FormItem>
          )}
        />

        {!showReferral ? (
          <button
            type="button"
            onClick={() => setShowReferral(true)}
            className="font-body text-sm text-muted-foreground hover:text-primary transition-colors"
          >
            Have a referral code?
          </button>
        ) : (
          <FormField
            control={form.control}
            name="referralCode"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="font-body text-sm text-muted-foreground uppercase tracking-wider">
                  Referral Code (Optional)
                </FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    placeholder="Enter code"
                    className="h-12 bg-background border-border focus:border-primary font-body uppercase"
                    maxLength={6}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )}

        {error && (
          <motion.p
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-destructive text-sm font-body"
          >
            {error}
          </motion.p>
        )}

        <Button
          type="submit"
          disabled={isLoading}
          className="w-full h-14 metallic-bg btn-shimmer text-primary-foreground font-display text-xl tracking-wider rounded-full"
        >
          {isLoading ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : (
            "Join the List"
          )}
        </Button>
      </form>
    </Form>
  );
}
