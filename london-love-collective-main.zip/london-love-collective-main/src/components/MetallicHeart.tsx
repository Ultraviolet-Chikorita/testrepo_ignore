import { motion } from "framer-motion";

interface MetallicHeartProps {
  size?: number;
  className?: string;
  shimmerDelay?: number;
  animate?: boolean;
}

export function MetallicHeart({ 
  size = 24, 
  className = "",
  shimmerDelay = 0,
  animate = true
}: MetallicHeartProps) {
  const uniqueId = `metallic-heart-${Math.random().toString(36).substr(2, 9)}`;
  
  return (
    <motion.svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      className={className}
      style={{ filter: "drop-shadow(0 4px 12px hsl(0 75% 30% / 0.4))" }}
    >
      <defs>
        {/* Main metallic gradient - dark to bright red with 3D depth */}
        <radialGradient id={`${uniqueId}-main`} cx="30%" cy="30%" r="70%">
          <stop offset="0%" stopColor="hsl(0, 85%, 60%)" />
          <stop offset="25%" stopColor="hsl(0, 80%, 50%)" />
          <stop offset="50%" stopColor="hsl(0, 75%, 40%)" />
          <stop offset="75%" stopColor="hsl(0, 70%, 30%)" />
          <stop offset="100%" stopColor="hsl(0, 65%, 22%)" />
        </radialGradient>
        
        {/* Top highlight for glossy effect */}
        <radialGradient id={`${uniqueId}-highlight`} cx="35%" cy="25%" r="40%">
          <stop offset="0%" stopColor="hsla(0, 0%, 100%, 0.7)" />
          <stop offset="50%" stopColor="hsla(0, 0%, 100%, 0.2)" />
          <stop offset="100%" stopColor="hsla(0, 0%, 100%, 0)" />
        </radialGradient>
        
        {/* Secondary reflection on left lobe */}
        <radialGradient id={`${uniqueId}-reflection`} cx="65%" cy="35%" r="30%">
          <stop offset="0%" stopColor="hsla(0, 80%, 65%, 0.6)" />
          <stop offset="100%" stopColor="hsla(0, 80%, 65%, 0)" />
        </radialGradient>
        
        {/* Shimmer gradient for animation */}
        <linearGradient id={`${uniqueId}-shimmer`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="hsla(0, 0%, 100%, 0)" />
          <stop offset="40%" stopColor="hsla(0, 0%, 100%, 0)" />
          <stop offset="50%" stopColor="hsla(0, 0%, 100%, 0.5)" />
          <stop offset="60%" stopColor="hsla(0, 0%, 100%, 0)" />
          <stop offset="100%" stopColor="hsla(0, 0%, 100%, 0)" />
        </linearGradient>
        
        {/* Clip path for shimmer */}
        <clipPath id={`${uniqueId}-clip`}>
          <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
        </clipPath>
      </defs>
      
      {/* Base heart shape with main gradient */}
      <path
        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
        fill={`url(#${uniqueId}-main)`}
      />
      
      {/* Highlight overlay for 3D glossy effect */}
      <path
        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
        fill={`url(#${uniqueId}-highlight)`}
      />
      
      {/* Secondary reflection */}
      <path
        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
        fill={`url(#${uniqueId}-reflection)`}
      />
      
      {/* Animated shimmer sweep */}
      {animate && (
        <g clipPath={`url(#${uniqueId}-clip)`}>
          <motion.rect
            x="-24"
            y="0"
            width="24"
            height="24"
            fill={`url(#${uniqueId}-shimmer)`}
            initial={{ x: -24 }}
            animate={{ x: 48 }}
            transition={{
              duration: 2,
              delay: shimmerDelay,
              repeat: Infinity,
              repeatDelay: 3,
              ease: "easeInOut",
            }}
          />
        </g>
      )}
    </motion.svg>
  );
}
