import { motion, useScroll, useTransform } from "framer-motion";
import { MapPin, Calendar, Wine, Theater } from "lucide-react";
import { Button } from "@/components/ui/button";
import { UniversityTicker } from "./UniversityTicker";
import { CloudBackground } from "./CloudBackground";
import { MetallicHeart } from "./MetallicHeart";

interface HeroSectionProps {
  onGetInvited: () => void;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.12,
      delayChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: "easeOut" as const,
    },
  },
};

export function HeroSection({ onGetInvited }: HeroSectionProps) {
  const titleLine1 = "CAMPUS LOVE";
  const titleLine2 = "LAB";
  
  // Scroll-based parallax effects
  const { scrollYProgress } = useScroll();
  const headlineY = useTransform(scrollYProgress, [0, 0.3], [0, -50]);
  const headlineOpacity = useTransform(scrollYProgress, [0, 0.25], [1, 0.6]);
  const detailsY = useTransform(scrollYProgress, [0, 0.3], [0, -30]);
  const scrollIndicatorOpacity = useTransform(scrollYProgress, [0, 0.08], [1, 0]);
  const backgroundScale = useTransform(scrollYProgress, [0, 0.5], [1, 1.1]);

  return (
    <section className="relative min-h-[85vh] flex flex-col justify-end overflow-hidden bg-background">
      {/* Animated cloud background with parallax */}
      <motion.div style={{ scale: backgroundScale }}>
        <CloudBackground />
      </motion.div>
      
      {/* Subtle gradient overlay for depth */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/10 to-background/30 pointer-events-none" />
      
      {/* Red to white gradient at top - on top of clouds */}
      <div className="absolute top-0 left-0 right-0 h-[60vh] bg-gradient-to-b from-primary/[0.23] via-primary/[0.08] via-40% to-transparent pointer-events-none z-[5]" />
      
      <div className="container relative z-10 px-4 pt-20 pb-0">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="text-center max-w-4xl mx-auto"
        >
          {/* Main show title with letter-by-letter animation */}
          <motion.h1
            className="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold tracking-tighter leading-tight mb-10"
            style={{ y: headlineY, opacity: headlineOpacity }}
          >
            {/* Line 1: CAMPUS LOVE */}
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="block metallic-heart relative overflow-hidden whitespace-nowrap"
            >
              {titleLine1.split("").map((letter, index) => (
                <motion.span
                  key={index}
                  initial={{ opacity: 0, y: 60, rotateX: -90, scale: 0.8 }}
                  animate={{ opacity: 1, y: 0, rotateX: 0, scale: 1 }}
                  transition={{
                    duration: 0.4,
                    delay: 0.2 + index * 0.03,
                    type: "spring",
                    stiffness: 300,
                    damping: 20,
                  }}
                  className="inline-block"
                >
                  {letter === " " ? "\u00A0" : letter}
                </motion.span>
              ))}
              {/* Shimmer overlay for CAMPUS LOVE */}
              <motion.span
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent pointer-events-none"
                initial={{ x: "-100%" }}
                animate={{ x: "200%" }}
                transition={{
                  duration: 1.2,
                  delay: 1.0,
                  repeat: Infinity,
                  repeatDelay: 4,
                  ease: "easeInOut",
                }}
              />
            </motion.span>
            
            {/* Line 2: LAB */}
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="block metallic-heart relative overflow-hidden whitespace-nowrap"
            >
              {titleLine2.split("").map((letter, index) => (
                <motion.span
                  key={index}
                  initial={{ opacity: 0, y: 60, rotateX: -90, scale: 0.8 }}
                  animate={{ opacity: 1, y: 0, rotateX: 0, scale: 1 }}
                  transition={{
                    duration: 0.4,
                    delay: 0.5 + index * 0.03,
                    type: "spring",
                    stiffness: 300,
                    damping: 20,
                  }}
                  className="inline-block"
                >
                  {letter}
                </motion.span>
              ))}
              {/* Shimmer overlay */}
              <motion.span
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent pointer-events-none"
                initial={{ x: "-100%" }}
                animate={{ x: "200%" }}
                transition={{
                  duration: 1.2,
                  delay: 1.0,
                  repeat: Infinity,
                  repeatDelay: 4,
                  ease: "easeInOut",
                }}
              />
            </motion.span>
          </motion.h1>
          
          {/* Tagline with controlled line breaks - more prominent */}
          <motion.div
            initial={{ opacity: 0, y: 20, filter: "blur(4px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            transition={{ duration: 0.5, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="font-display text-2xl sm:text-3xl md:text-4xl text-foreground tracking-wide mb-10"
          >
            <span className="block whitespace-nowrap font-medium">
              London's Biggest <span className="metallic-heart font-bold">Valentine's</span>
            </span>
            <span className="block whitespace-nowrap italic font-light mt-2 text-muted-foreground">
              Social Experiment
            </span>
          </motion.div>
          
          {/* Floating metallic heart accent near headline */}
          <motion.div
            className="absolute top-1/4 right-[15%] hidden lg:block"
            initial={{ opacity: 0, scale: 0, rotate: -30 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ 
              duration: 0.6, 
              delay: 0.8,
              type: "spring",
              stiffness: 200
            }}
          >
            <motion.div
              animate={{
                y: [0, -15, 0],
                rotate: [0, 10, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <MetallicHeart size={48} shimmerDelay={1} />
            </motion.div>
          </motion.div>
          
          
          {/* Event details bar with snappy stagger and scroll parallax */}
          <motion.div
            variants={itemVariants}
            className="flex flex-wrap justify-center gap-4 md:gap-8 mb-12 text-base md:text-lg"
            style={{ y: detailsY }}
          >
            {[
              { icon: MapPin, text: "Imperial" },
              { icon: Calendar, text: "14 Feb" },
              { icon: Wine, text: "Drinks" },
              { icon: Theater, text: "Audience games" },
            ].map((item, index) => (
              <motion.div
                key={item.text}
                initial={{ opacity: 0, x: -20, filter: "blur(4px)" }}
                animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
                transition={{
                  duration: 0.4,
                  delay: 0.9 + index * 0.08,
                  type: "spring",
                  stiffness: 300,
                }}
                whileHover={{ scale: 1.08 }}
                className="flex items-center gap-2 text-muted-foreground"
              >
                <item.icon size={20} className="text-primary" />
                <span className="font-display text-base md:text-lg tracking-wide">{item.text}</span>
              </motion.div>
            ))}
          </motion.div>
          
          
          {/* CTA Button with magnetic hover effect */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1.4 }}
            className="mb-6"
          >
            <motion.div
              whileHover={{ scale: 1.06 }}
              whileTap={{ scale: 0.97 }}
              transition={{ type: "spring", stiffness: 400, damping: 17 }}
            >
              <Button
                onClick={onGetInvited}
                size="lg"
                className="metallic-bg btn-shimmer text-primary-foreground font-display text-xl tracking-wider px-12 py-6 rounded-full shadow-lg hover:shadow-2xl transition-shadow uppercase"
              >
                Get Invited
              </Button>
            </motion.div>
          </motion.div>
          
          {/* Scarcity text with subtle pulse */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 1.6 }}
            className="font-display text-base md:text-lg text-muted-foreground tracking-wide font-semibold"
          >
            <motion.span
              animate={{ opacity: [0.7, 1, 0.7] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            >
              Invite-Only. 300 Seats.
            </motion.span>
          </motion.p>
        </motion.div>
      </div>
      
      {/* Scroll indicator with metallic glow - fades on scroll */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
        style={{ opacity: scrollIndicatorOpacity }}
      >
        <motion.div
          animate={{ y: [0, 12, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
          className="w-6 h-10 rounded-full border-2 border-primary/40 flex items-start justify-center p-2"
          style={{
            boxShadow: "0 0 15px hsl(0 75% 40% / 0.3)",
          }}
        >
          <motion.div
            animate={{ height: ["20%", "50%", "20%"] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
            className="w-1 bg-primary/60 rounded-full"
          />
        </motion.div>
      </motion.div>
      
      {/* University ticker at bottom */}
      <div className="relative z-10 mt-auto">
        <UniversityTicker />
      </div>
    </section>
  );
}
