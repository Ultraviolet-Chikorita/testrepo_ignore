import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface SignupData {
  firstName: string;
  university: string;
  phone: string;
  referralCode?: string;
}

interface SignupResult {
  id: string;
  referralCode: string;
  queuePosition: number;
}

export function useSignup() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateReferralCode = (): string => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let result = "";
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  };

  const signup = async (data: SignupData): Promise<SignupResult | null> => {
    setIsLoading(true);
    setError(null);

    try {
      // Generate unique referral code (check via secure function)
      let newReferralCode = generateReferralCode();
      let attempts = 0;
      while (attempts < 5) {
        const { data: exists } = await supabase.rpc("check_referral_code_exists", {
          code: newReferralCode,
        });

        if (!exists) break;
        newReferralCode = generateReferralCode();
        attempts++;
      }

      // Use secure RPC function to create signup
      const { data: result, error: signupError } = await supabase.rpc("create_signup", {
        p_first_name: data.firstName.trim(),
        p_university: data.university,
        p_phone: data.phone.trim(),
        p_referral_code: newReferralCode,
        p_referred_by_code: data.referralCode?.toUpperCase() || null,
      });

      if (signupError) throw signupError;

      // Check if the function returned an error
      if (result && typeof result === 'object' && 'error' in result) {
        const errorResult = result as { error: string };
        if (errorResult.error === 'Phone number already registered') {
          setError("This phone number is already registered.");
          setIsLoading(false);
          return null;
        }
        throw new Error(errorResult.error);
      }

      const successResult = result as { id: string; referral_code: string; queue_position: number };

      setIsLoading(false);
      return {
        id: successResult.id,
        referralCode: successResult.referral_code,
        queuePosition: successResult.queue_position,
      };
    } catch (err) {
      console.error("Signup error:", err);
      setError("Something went wrong. Please try again.");
      setIsLoading(false);
      return null;
    }
  };

  return { signup, isLoading, error };
}
