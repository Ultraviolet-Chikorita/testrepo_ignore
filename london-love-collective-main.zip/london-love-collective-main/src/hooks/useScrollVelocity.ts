import { useScroll, useVelocity, useSpring, useTransform, MotionValue } from "framer-motion";
import { useRef, useEffect, useState } from "react";

interface ScrollVelocityResult {
  scrollY: MotionValue<number>;
  scrollYProgress: MotionValue<number>;
  velocity: MotionValue<number>;
  // Smoothed velocity between 0-1 for animation intensity
  intensity: MotionValue<number>;
  // Boolean for "is scrolling fast"
  isFastScrolling: boolean;
}

export function useScrollVelocity(): ScrollVelocityResult {
  const { scrollY, scrollYProgress } = useScroll();
  const velocity = useVelocity(scrollY);
  const [isFastScrolling, setIsFastScrolling] = useState(false);
  
  // Smooth the velocity for more organic feel
  const smoothVelocity = useSpring(velocity, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001,
  });
  
  // Transform velocity to 0-1 intensity scale
  // Map velocity range (-2000 to 2000) to (0 to 1)
  const intensity = useTransform(
    smoothVelocity,
    [-2000, -500, 0, 500, 2000],
    [1, 0.7, 0, 0.7, 1]
  );
  
  // Track if scrolling fast
  useEffect(() => {
    return velocity.on("change", (v) => {
      setIsFastScrolling(Math.abs(v) > 500);
    });
  }, [velocity]);
  
  return {
    scrollY,
    scrollYProgress,
    velocity: smoothVelocity,
    intensity,
    isFastScrolling,
  };
}

// Hook for individual element scroll progress with velocity
export function useElementScrollVelocity(offset: ["start end" | "end start", "start end" | "end start"] = ["start end", "end start"]) {
  const ref = useRef<HTMLElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: ref,
    offset,
  });
  
  const velocity = useVelocity(scrollYProgress);
  
  const smoothVelocity = useSpring(velocity, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001,
  });
  
  return {
    ref,
    scrollYProgress,
    velocity: smoothVelocity,
  };
}
