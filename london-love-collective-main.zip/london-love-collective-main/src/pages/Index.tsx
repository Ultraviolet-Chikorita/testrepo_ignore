import { useState, useRef } from "react";
import { useSearchParams } from "react-router-dom";
import { HeroSection } from "@/components/HeroSection";
import { WhyParticipateSection } from "@/components/WhyParticipateSection";
import { GamesSection } from "@/components/GamesSection";
import { InviteOnlySection } from "@/components/InviteOnlySection";
import { SignupSection } from "@/components/SignupSection";
import { ConfirmationScreen } from "@/components/ConfirmationScreen";
import { PriorityUnlock } from "@/components/PriorityUnlock";
import { ReferralScreen } from "@/components/ReferralScreen";
import { ScrollProgress } from "@/components/ScrollProgress";
import { FloatingHearts } from "@/components/FloatingHearts";
import onesoulLogo from "@/assets/onesoul-logo.svg";

type FlowStep = "landing" | "confirmation" | "priority" | "referral";

interface SignupData {
  id: string;
  referralCode: string;
  queuePosition: number;
}

const Index = () => {
  const [searchParams] = useSearchParams();
  const [flowStep, setFlowStep] = useState<FlowStep>("landing");
  const [signupData, setSignupData] = useState<SignupData | null>(null);
  const signupRef = useRef<HTMLElement>(null);

  // Get referral code from URL if present
  const initialReferralCode = searchParams.get("ref") || undefined;

  const scrollToSignup = () => {
    signupRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleSignupSuccess = (data: SignupData) => {
    setSignupData(data);
    setFlowStep("confirmation");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleUnlockPriority = () => {
    setFlowStep("priority");
  };

  const handlePriorityComplete = (newPosition: number) => {
    if (signupData) {
      setSignupData({ ...signupData, queuePosition: newPosition });
    }
    setFlowStep("referral");
  };

  // Show different screens based on flow step
  if (flowStep === "confirmation" && signupData) {
    return (
      <ConfirmationScreen
        queuePosition={signupData.queuePosition}
        onUnlockPriority={handleUnlockPriority}
      />
    );
  }

  if (flowStep === "priority" && signupData) {
    return (
      <PriorityUnlock
        signupId={signupData.id}
        onComplete={handlePriorityComplete}
      />
    );
  }

  if (flowStep === "referral" && signupData) {
    return (
      <ReferralScreen
        referralCode={signupData.referralCode}
        queuePosition={signupData.queuePosition}
        signupId={signupData.id}
      />
    );
  }

  // Main landing page
  return (
    <main className="relative">
      {/* Scroll progress indicator */}
      <ScrollProgress />
      
      {/* Falling hearts - full page */}
      <FloatingHearts />
      
      {/* Grain overlay */}
      <div className="grain-overlay" />

      <HeroSection onGetInvited={scrollToSignup} />
      
      <WhyParticipateSection />
      
      <GamesSection />
      
      <InviteOnlySection />
      
      <SignupSection
        ref={signupRef}
        onSuccess={handleSignupSuccess}
        initialReferralCode={initialReferralCode}
      />

      {/* Footer */}
      <footer className="py-6 bg-muted/30 border-t border-border/30">
        <div className="container px-4">
          <div className="flex flex-col items-center gap-3">
            <p className="font-display text-sm tracking-widest text-muted-foreground/80">
              Valentine's 2026 · London
            </p>
            <a 
              href="https://1soul.ai" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-muted-foreground/60 hover:text-foreground transition-colors group"
            >
              <span className="font-display text-xs tracking-wide">Sponsored by 1soul.ai</span>
              <img 
                src={onesoulLogo} 
                alt="1soul.ai" 
                className="h-4 w-auto opacity-60 group-hover:opacity-100 transition-opacity"
              />
            </a>
          </div>
        </div>
      </footer>
    </main>
  );
};

export default Index;
