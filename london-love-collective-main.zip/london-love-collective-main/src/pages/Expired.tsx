import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Clock, Heart, ArrowRight } from "lucide-react";
import { FloatingHearts } from "@/components/FloatingHearts";

const Expired = () => {
  return (
    <main className="min-h-screen relative flex flex-col items-center justify-center px-4 py-12">
      <FloatingHearts />
      <div className="grain-overlay" />
      
      <div className="relative z-20 w-full max-w-md text-center">
        {/* Expired icon */}
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-muted/20 mb-6">
          <Clock className="w-10 h-10 text-muted-foreground" />
        </div>

        {/* Header */}
        <h1 className="font-display text-4xl md:text-5xl tracking-tight mb-3">
          Invite Expired
        </h1>
        <p className="text-muted-foreground mb-8 max-w-sm mx-auto">
          Your invite link has expired. Don't worry — you can still join the waitlist for a chance to get another invite.
        </p>

        {/* CTA */}
        <div className="space-y-4">
          <Button asChild size="lg" className="w-full h-14 text-lg font-semibold gap-2">
            <Link to="/">
              <Heart className="w-5 h-5" />
              Join the Waitlist
              <ArrowRight className="w-5 h-5" />
            </Link>
          </Button>
          
          <p className="text-sm text-muted-foreground">
            Priority given to early signups and referrals
          </p>
        </div>

        {/* Info card */}
        <div className="mt-12 bg-card/30 border border-border/30 rounded-xl p-6 text-left">
          <h2 className="font-display text-base mb-3 flex items-center gap-2">
            <Heart className="w-4 h-4 text-primary" />
            Why do invites expire?
          </h2>
          <p className="text-sm text-muted-foreground">
            We have limited seats (300 total) and want to give everyone a fair chance. 
            Expired invites are released back to the waitlist so others can claim them.
          </p>
        </div>
      </div>
    </main>
  );
};

export default Expired;
