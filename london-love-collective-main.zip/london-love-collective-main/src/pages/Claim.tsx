import { useSearchParams } from "react-router-dom";
import { Heart, Lock, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FloatingHearts } from "@/components/FloatingHearts";

const STRIPE_PAYMENT_LINK = "https://buy.stripe.com/4gM9AT5CB2vM3uP8WB38400";

const Claim = () => {
  const [searchParams] = useSearchParams();
  const canceled = searchParams.get("canceled") === "1";

  const universities = ["Imperial", "UCL", "KCL", "LSE", "City"];

  return (
    <main className="min-h-screen relative flex flex-col items-center justify-center px-4 py-12">
      <FloatingHearts />
      <div className="grain-overlay" />
      
      <div className="relative z-20 w-full max-w-md">
        {/* Canceled banner */}
        {canceled && (
          <div className="mb-6 p-4 bg-accent/10 border border-accent/30 rounded-lg flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
            <p className="text-sm text-muted-foreground">
              Payment cancelled. You can try again when you're ready.
            </p>
          </div>
        )}

        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
            <Heart className="w-8 h-8 text-primary" />
          </div>
          <h1 className="font-display text-4xl md:text-5xl tracking-tight mb-3">
            Claim Your Seat
          </h1>
          <p className="text-xl text-primary font-semibold mb-4">£5</p>
          <p className="text-muted-foreground text-sm">
            London Inter-Uni Valentine's Show
          </p>
        </div>

        {/* Event details card */}
        <div className="bg-card/50 backdrop-blur-sm border border-border/50 rounded-2xl p-6 md:p-8 space-y-6">
          {/* Event info */}
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Date</span>
              <span className="font-medium">14th February 2025</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Venue</span>
              <span className="font-medium">Imperial College London</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Capacity</span>
              <span className="font-medium">300 seats</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Entry</span>
              <span className="font-medium">Invite-only</span>
            </div>
          </div>

          {/* Payment button */}
          <Button
            asChild
            className="w-full h-14 text-lg font-semibold"
          >
            <a href={STRIPE_PAYMENT_LINK} target="_blank" rel="noopener noreferrer">
              Confirm My Seat — £5
            </a>
          </Button>

          <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
            <Lock className="w-3 h-3" />
            <span>Secure checkout by Stripe</span>
          </div>
        </div>

        {/* University logos */}
        <div className="mt-8 flex items-center justify-center gap-4 text-xs text-muted-foreground/60">
          {universities.map((uni) => (
            <span key={uni} className="font-medium">{uni}</span>
          ))}
        </div>

        {/* Fine print */}
        <p className="mt-6 text-center text-xs text-muted-foreground/50">
          Non-refundable · Filmed event · 18+ · ID may be checked
        </p>
      </div>
    </main>
  );
};

export default Claim;
