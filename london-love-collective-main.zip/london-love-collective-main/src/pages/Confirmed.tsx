import { useState, useEffect } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Heart, Check, Copy, Share2, MessageCircle } from "lucide-react";
import { FloatingHearts } from "@/components/FloatingHearts";
import { toast } from "sonner";

const Confirmed = () => {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get("session_id");
  const [copied, setCopied] = useState(false);

  // Generate ticket reference from session ID
  const ticketReference = sessionId 
    ? `CLL-${sessionId.slice(-6).toUpperCase()}`
    : "CLL-XXXXXX";

  const shareUrl = "https://campuslovelab.co";
  const shareText = "I just claimed my seat at Campus Love Lab! 💕 Join the waitlist:";

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(`${shareText} ${shareUrl}`);
      setCopied(true);
      toast.success("Copied to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error("Failed to copy");
    }
  };

  const shareWhatsApp = () => {
    const url = `https://wa.me/?text=${encodeURIComponent(`${shareText} ${shareUrl}`)}`;
    window.open(url, "_blank");
  };

  const shareInstagram = () => {
    // Instagram doesn't have a direct share URL, so we copy and show instructions
    copyToClipboard();
    toast.info("Text copied! Paste it in your Instagram story.");
  };

  return (
    <main className="min-h-screen relative flex flex-col items-center justify-center px-4 py-12">
      <FloatingHearts />
      <div className="grain-overlay" />
      
      <div className="relative z-20 w-full max-w-md text-center">
        {/* Success icon */}
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-500/20 mb-6">
          <div className="w-14 h-14 rounded-full bg-green-500/30 flex items-center justify-center">
            <Check className="w-8 h-8 text-green-400" />
          </div>
        </div>

        {/* Header */}
        <h1 className="font-display text-4xl md:text-5xl tracking-tight mb-3">
          Seat Confirmed ✅
        </h1>
        <p className="text-muted-foreground mb-8">
          You'll receive a receipt from Stripe. Bring ID on the night.
        </p>

        {/* Ticket reference */}
        <div className="bg-card/50 backdrop-blur-sm border border-border/50 rounded-2xl p-6 mb-8">
          <p className="text-sm text-muted-foreground mb-2">Your ticket reference</p>
          <p className="font-mono text-2xl md:text-3xl font-bold tracking-wider text-primary">
            {ticketReference}
          </p>
        </div>

        {/* What happens next */}
        <div className="bg-card/30 border border-border/30 rounded-xl p-6 mb-8 text-left">
          <h2 className="font-display text-lg mb-4 flex items-center gap-2">
            <Heart className="w-4 h-4 text-primary" />
            What happens next
          </h2>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li className="flex items-start gap-3">
              <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center flex-shrink-0 mt-0.5">1</span>
              <span>You'll get arrival instructions 48 hours before the show.</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center flex-shrink-0 mt-0.5">2</span>
              <span>Want to sit with a friend? If they claim a seat, we'll seat you together.</span>
            </li>
          </ul>
        </div>

        {/* Share section */}
        <div className="bg-primary/5 border border-primary/20 rounded-xl p-6 mb-8">
          <p className="font-medium mb-4 text-sm">
            Bring 1 friend → we'll seat you together 💕
          </p>
          <div className="flex items-center justify-center gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={shareWhatsApp}
              className="gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              WhatsApp
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={shareInstagram}
              className="gap-2"
            >
              <Share2 className="w-4 h-4" />
              IG Story
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={copyToClipboard}
              className="gap-2"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? "Copied!" : "Copy"}
            </Button>
          </div>
        </div>

        {/* Fine print */}
        <p className="text-xs text-muted-foreground/60">
          Doors 18:45 · Filming consent at entry · Smart casual
        </p>

        {/* Back home link */}
        <Link 
          to="/" 
          className="inline-block mt-8 text-sm text-primary hover:underline"
        >
          ← Back to home
        </Link>
      </div>
    </main>
  );
};

export default Confirmed;
